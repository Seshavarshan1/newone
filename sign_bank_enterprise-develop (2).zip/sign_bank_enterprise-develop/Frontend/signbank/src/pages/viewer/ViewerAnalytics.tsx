import { useState, useEffect, useCallback, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import PortalLayout from '../../components/Layout/PortalLayout';
import GestureCamera from '../../components/GestureCamera/GestureCamera';
import { fetchLogs } from '../../api/logsApi';
import { useAuth } from '../../context/AuthContext';
import {
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, Legend, LineChart, Line, CartesianGrid,
} from 'recharts';
import type { InteractionLog } from '../../types';
import type { GestureEvent } from '../../hooks/useGestureControl';
import './ViewerAnalytics.css';

const COLORS = ['#059669', '#ef4444', '#7c3aed', '#f59e0b', '#2563eb'];
const POLL_MS = 15_000;

export default function ViewerAnalytics() {
  const { currentUser } = useAuth();
  const navigate = useNavigate();
  const [logs,    setLogs]    = useState<InteractionLog[]>([]);
  const [loading, setLoading] = useState(true);
  const [lastRefresh, setLastRefresh] = useState<Date | null>(null);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const loadLogs = useCallback(async () => {
    if (!currentUser) return;
    try {
      const all = await fetchLogs();
      const mine = all.filter(l => l.user?.userId === currentUser.userId);
      setLogs(mine);
      setLastRefresh(new Date());
    } catch (_) {
      // keep stale data on error
    } finally {
      setLoading(false);
    }
  }, [currentUser]);

  useEffect(() => {
    loadLogs();
    timerRef.current = setInterval(loadLogs, POLL_MS);
    return () => { if (timerRef.current) clearInterval(timerRef.current); };
  }, [loadLogs]);

  const handleGesture = useCallback((evt: GestureEvent) => {
    if (evt.type === 'GESTURE_ID' && evt.id === 'G003') navigate('/viewer/dashboard');
  }, [navigate]);

  // ── Derived data ──────────────────────────────────────────────────────────
  const total   = logs.length;
  const success = logs.filter(l => l.status === 'success').length;
  const failed  = logs.filter(l => l.status === 'failed').length;
  const rate    = total > 0 ? Math.round((success / total) * 100) : 0;

  // Gesture usage
  const gestureMap = new Map<string, { name: string; symbol: string; count: number }>();
  logs.forEach(l => {
    if (!l.gesture) return;
    const key = l.gesture.gestureId;
    const ex  = gestureMap.get(key);
    if (ex) ex.count++;
    else gestureMap.set(key, {
      name:   l.gesture.gestureName,
      symbol: l.gesture.gestureSymbol ?? '',
      count:  1,
    });
  });
  const gestureUsage = Array.from(gestureMap.values()).sort((a, b) => b.count - a.count);

  // Status pie
  const statusData = [
    { name: 'Success', value: success },
    { name: 'Failed',  value: failed  },
  ].filter(d => d.value > 0);

  // Activity over last 7 days
  const dayMap = new Map<string, { date: string; count: number }>();
  for (let i = 6; i >= 0; i--) {
    const d = new Date(); d.setDate(d.getDate() - i);
    const key = d.toLocaleDateString('en-IN', { month: 'short', day: 'numeric' });
    dayMap.set(key, { date: key, count: 0 });
  }
  logs.forEach(l => {
    const d   = new Date(l.executedAt);
    const key = d.toLocaleDateString('en-IN', { month: 'short', day: 'numeric' });
    const ex  = dayMap.get(key);
    if (ex) ex.count++;
  });
  const activityData = Array.from(dayMap.values());

  // Command usage
  const cmdMap = new Map<string, { name: string; count: number }>();
  logs.forEach(l => {
    if (!l.command) return;
    const key = l.command.commandId;
    const ex  = cmdMap.get(key);
    if (ex) ex.count++;
    else cmdMap.set(key, { name: l.command.commandName, count: 1 });
  });
  const commandUsage = Array.from(cmdMap.values()).sort((a, b) => b.count - a.count);

  return (
    <PortalLayout title="Viewer" subtitle="Analytics" backPath="/viewer/dashboard" showLogout={false}>
      <div className="viewer-analytics-layout">
        <div className="analytics-content">

          <div className="analytics-header-row">
            <h2>My Analytics</h2>
            <div className="analytics-meta">
              {lastRefresh && (
                <span className="last-refresh">Updated: {lastRefresh.toLocaleTimeString()}</span>
              )}
              <button className="refresh-btn" onClick={loadLogs} disabled={loading}>
                {loading ? '⟳ Loading…' : '⟳ Refresh'}
              </button>
            </div>
          </div>

          {/* KPI stats */}
          <div className="stat-row">
            <div className="mini-stat purple">
              <div className="ms-num">{total}</div>
              <div className="ms-label">Total Interactions</div>
            </div>
            <div className="mini-stat green">
              <div className="ms-num">{success}</div>
              <div className="ms-label">Successful</div>
            </div>
            <div className="mini-stat red">
              <div className="ms-num">{failed}</div>
              <div className="ms-label">Failed</div>
            </div>
            <div className="mini-stat blue">
              <div className="ms-num">{rate}%</div>
              <div className="ms-label">Success Rate</div>
            </div>
          </div>

          {loading && total === 0 ? (
            <div className="no-data">Loading analytics…</div>
          ) : total === 0 ? (
            <div className="no-data">No interaction data yet. Start using commands to see analytics.</div>
          ) : (
            <div className="viewer-charts">

              {/* Activity Line Chart */}
              <div className="chart-card full-width">
                <h3>Activity — Last 7 Days</h3>
                <ResponsiveContainer width="100%" height={180}>
                  <LineChart data={activityData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                    <XAxis dataKey="date" tick={{ fontSize: 10 }} />
                    <YAxis allowDecimals={false} tick={{ fontSize: 10 }} />
                    <Tooltip />
                    <Line type="monotone" dataKey="count" stroke="#7c3aed"
                          strokeWidth={2} dot={{ r: 4 }} activeDot={{ r: 6 }} />
                  </LineChart>
                </ResponsiveContainer>
              </div>

              {/* Gesture usage bar */}
              <div className="chart-card">
                <h3>Gesture Usage</h3>
                {gestureUsage.length > 0 ? (
                  <ResponsiveContainer width="100%" height={200}>
                    <BarChart data={gestureUsage}>
                      <XAxis dataKey="name" tick={{ fontSize: 9 }} />
                      <YAxis allowDecimals={false} tick={{ fontSize: 10 }} />
                      <Tooltip
                        formatter={(v, _n, p) => [v, `${p.payload.symbol} ${p.payload.name}`]}
                      />
                      <Bar dataKey="count" fill="#7c3aed" radius={[4, 4, 0, 0]}>
                        {gestureUsage.map((_, i) => (
                          <Cell key={i} fill={COLORS[i % COLORS.length]} />
                        ))}
                      </Bar>
                    </BarChart>
                  </ResponsiveContainer>
                ) : <p className="no-data">No gesture data</p>}
              </div>

              {/* Status pie */}
              <div className="chart-card">
                <h3>Status Distribution</h3>
                {statusData.length > 0 ? (
                  <ResponsiveContainer width="100%" height={200}>
                    <PieChart>
                      <Pie data={statusData} dataKey="value" nameKey="name"
                           cx="50%" cy="50%" outerRadius={70} label={({ name, percent }) =>
                             `${name} ${(percent * 100).toFixed(0)}%`}>
                        {statusData.map((_, i) => (
                          <Cell key={i} fill={i === 0 ? '#059669' : '#ef4444'} />
                        ))}
                      </Pie>
                      <Legend /><Tooltip />
                    </PieChart>
                  </ResponsiveContainer>
                ) : <p className="no-data">No data</p>}
              </div>

              {/* Command usage */}
              {commandUsage.length > 0 && (
                <div className="chart-card full-width">
                  <h3>Command Usage</h3>
                  <ResponsiveContainer width="100%" height={180}>
                    <BarChart data={commandUsage}>
                      <XAxis dataKey="name" tick={{ fontSize: 10 }} />
                      <YAxis allowDecimals={false} tick={{ fontSize: 10 }} />
                      <Tooltip />
                      <Bar dataKey="count" fill="#059669" radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              )}

            </div>
          )}
        </div>

        <GestureCamera onGesture={handleGesture} />
      </div>
    </PortalLayout>
  );
}
