package com.signbank.backend.controller;

import com.signbank.backend.dto.AuthResponse;
import com.signbank.backend.dto.RegisterRequest;
import com.signbank.backend.entity.User;
import com.signbank.backend.repository.UserRepository;
import com.signbank.backend.security.JwtUtil;
import com.signbank.backend.service.AuthService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private final UserRepository userRepo;
    private final JwtUtil jwtUtil;
    private final AuthService authService;
    private final PasswordEncoder passwordEncoder;

    public AuthController(UserRepository userRepo, JwtUtil jwtUtil,
                          AuthService authService, PasswordEncoder passwordEncoder) {
        this.userRepo = userRepo;
        this.jwtUtil = jwtUtil;
        this.authService = authService;
        this.passwordEncoder = passwordEncoder;
    }

    /**
     * STEP 1 — Check if user exists and whether password is set.
     *
     * POST /api/auth/login?userId=1111          (no password param)
     *   → "FIRST_LOGIN"        if password_hash is NULL  (go to /set-password)
     *   → "PASSWORD_REQUIRED"  if password_hash exists   (show password/gesture screen)
     *
     * Admin always needs a password, returns "PASSWORD_REQUIRED".
     *
     * STEP 2 — Verify password.
     *
     * Admin  : POST /api/auth/login?userId=U000&password=admin123
     *   → validates BCrypt password_hash
     *   → auto-upgrades plain-text placeholder hash on first match
     *
     * Operator/Viewer: POST /api/auth/login?userId=1111&password=G006-G005-G004
     *   → the "password" is the gesture sequence string (e.g. "G006-G005-G004")
     *   → validates BCrypt(gesture_sequence) stored in password_hash
     *   → on success returns JWT
     */
    @PostMapping("/login")
    public ResponseEntity<String> login(
            @RequestParam(name = "userId") String userId,
            @RequestParam(name = "password", required = false) String password) {

        User user = userRepo.findById(userId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "User not found"));

        String roleName = user.getRole().getRoleName().toLowerCase();

        // ── Step 1: no password/gesture supplied ──────────────────────────
        if (password == null || password.isBlank()) {
            if (roleName.equals("admin")) {
                throw new ResponseStatusException(HttpStatus.UNAUTHORIZED,
                        "Password required for admin");
            }
            // Operator/Viewer: check if password_hash is set
            if (user.getPasswordHash() == null || user.getPasswordHash().isBlank()) {
                return ResponseEntity.ok("FIRST_LOGIN");
            }
            return ResponseEntity.ok("PASSWORD_REQUIRED");
        }

        // ── Step 2: verify the supplied password/gesture sequence ─────────
        String stored = user.getPasswordHash();

        if (stored == null || stored.isBlank()) {
            // No password set — send to first login
            return ResponseEntity.ok("FIRST_LOGIN");
        }

        boolean authenticated;
        if (stored.startsWith("$2a$") || stored.startsWith("$2b$") || stored.startsWith("$2y$")) {
            // Proper BCrypt hash — works for BOTH admin password AND gesture sequence hash
            authenticated = passwordEncoder.matches(password, stored);
        } else {
            // Plain-text placeholder in DB (e.g. admin seed data)
            // Compare directly then auto-upgrade to BCrypt
            authenticated = password.equals(stored);
            if (authenticated) {
                user.setPasswordHash(passwordEncoder.encode(password));
                userRepo.save(user);
            }
        }

        if (!authenticated) {
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Invalid credentials");
        }

        String token = jwtUtil.generateToken(
                user.getUserId(),
                user.getRole().getRoleName().toUpperCase()
        );
        return ResponseEntity.ok(token);
    }

    /**
     * SET PASSWORD (first login only).
     *
     * For Operator/Viewer: the "password" is the gesture sequence string e.g. "G006-G005-G004"
     * For Admin: the "password" is a plain text password
     *
     * BCrypt hashes it and stores in password_hash column.
     * Returns a JWT so the user is auto-logged-in after setting.
     *
     * POST /api/auth/set-password?userId=1111&newPassword=G006-G005-G004
     */
    @PostMapping("/set-password")
    public ResponseEntity<String> setPassword(
            @RequestParam String userId,
            @RequestParam String newPassword) {

        if (newPassword == null || newPassword.isBlank()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                    "Password cannot be empty");
        }

        User user = userRepo.findById(userId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND,
                        "User not found"));

        // BCrypt hash the gesture sequence (or admin password) and store in password_hash
        user.setPasswordHash(passwordEncoder.encode(newPassword));
        userRepo.save(user);

        String token = jwtUtil.generateToken(
                user.getUserId(),
                user.getRole().getRoleName().toUpperCase()
        );
        return ResponseEntity.ok(token);
    }

    /**
     * RESET PASSWORD — admin resets any user's password.
     * POST /api/auth/reset-password?userId=1111&newPassword=G006-G005
     */
    @PostMapping("/reset-password")
    public ResponseEntity<String> resetPassword(
            @RequestParam String userId,
            @RequestParam String newPassword) {

        User user = userRepo.findById(userId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND,
                        "User not found"));

        user.setPasswordHash(passwordEncoder.encode(newPassword));
        userRepo.save(user);
        return ResponseEntity.ok("Password reset for " + userId);
    }

    @PostMapping("/register")
    public ResponseEntity<AuthResponse> register(
            @Valid @RequestBody RegisterRequest request) {
        return ResponseEntity.ok(authService.register(request));
    }
}