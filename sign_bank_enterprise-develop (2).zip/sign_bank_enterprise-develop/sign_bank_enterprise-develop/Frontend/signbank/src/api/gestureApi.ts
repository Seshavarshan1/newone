/**
 * Gesture Event API
 * POST /api/gesture-events — { gestureCode, confidence } → { resolvedCommand, status }
 */
import apiClient from './client';

export interface GestureEventPayload {
  gestureCode: string;
  confidence: number;
}

export interface GestureEventResponse {
  resolvedCommand: string;
  status: string;
}

export const submitGestureEvent = (payload: GestureEventPayload): Promise<GestureEventResponse> =>
  apiClient.post('/api/gesture-events', payload).then(r => r.data);
