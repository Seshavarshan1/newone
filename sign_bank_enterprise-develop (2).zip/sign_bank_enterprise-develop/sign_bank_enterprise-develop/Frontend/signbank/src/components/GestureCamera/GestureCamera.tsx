import { useRef, useState } from 'react';
import { useGestureControl, type GestureEvent } from '../../hooks/useGestureControl';
import './GestureCamera.css';

interface Props {
  onGesture?: (event: GestureEvent) => void;
  // legacy compat
  onGestureDetected?: (name: string) => void;
}

export default function GestureCamera({ onGesture, onGestureDetected }: Props) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [lastGesture, setLastGesture] = useState('');
  const [active, setActive] = useState(false);

  useGestureControl(videoRef, canvasRef, {
    onGesture: (evt) => {
      // Show label
      const label =
        evt.type === 'DIGIT'      ? `${evt.value} finger(s)` :
        evt.type === 'GESTURE_ID' ? evt.id :
        evt.type;
      setLastGesture(label);
      setActive(true);

      onGesture?.(evt);
      // legacy: pass gesture name string
      if (onGestureDetected) {
        if (evt.type === 'DIGIT') onGestureDetected(evt.value);
        else onGestureDetected(evt.type);
      }
    },
  });

  return (
    <div className="gesture-camera">
      <div className="camera-header">
        <span className="camera-title">Live Gesture Detection</span>
        <span className={`status-dot ${active ? 'active' : 'loading'}`}>
          {active ? '● Active' : '● Loading'}
        </span>
      </div>

      <div className="camera-feed">
        <video ref={videoRef} className="camera-video" playsInline muted />
        <canvas ref={canvasRef} className="camera-canvas" />
      </div>

      <div className="camera-prompt">Show a hand gesture to continue</div>
      <div className="ai-status">
        AI Detection Status: <span className={active ? 'ready' : 'not-ready'}>{active ? 'Ready' : 'Initializing'}</span>
        {lastGesture && <span className="detected-gesture"> · {lastGesture}</span>}
      </div>
    </div>
  );
}
