import { useEffect, useRef } from 'react';

// Maps finger count / special gesture name → semantic action name
export type GestureEvent =
  | { type: 'DIGIT'; value: string }        // '0'..'9'
  | { type: 'THUMB_UP' }                    // Sign In / Submit / Confirm
  | { type: 'THUMB_DOWN' }                  // Backspace
  | { type: 'FIST' }                        // Back / Logout
  | { type: 'ROCK' }                        // Switch field
  | { type: 'OK' }                          // OK / select
  | { type: 'GESTURE_ID'; id: string };     // G001..G009 mapped from finger count

// finger count → gesture_id in our DB
const FINGER_TO_GESTURE_ID: Record<string, string> = {
  '1': 'G001', // One Finger
  '2': 'G002', // Two Finger
  '3': 'G003', // Three Finger
  '4': 'G004', // Closed Mid Two
  '5': 'G005', // Open Palm
};

export interface UseGestureControlOptions {
  onGesture: (event: GestureEvent) => void;
  enabled?: boolean;
}

declare const Hands: any;
declare const HAND_CONNECTIONS: any;
declare const drawConnectors: any;
declare const drawLandmarks: any;

export function useGestureControl(
  videoRef: React.RefObject<HTMLVideoElement | null>,
  canvasRef: React.RefObject<HTMLCanvasElement | null>,
  { onGesture, enabled = true }: UseGestureControlOptions
) {
  const onGestureRef = useRef(onGesture);
  useEffect(() => { onGestureRef.current = onGesture; }, [onGesture]);

  const enabledRef = useRef(enabled);
  useEffect(() => { enabledRef.current = enabled; }, [enabled]);

  useEffect(() => {
    let cancelled = false;
    let animId = 0;
    let handsInstance: any = null;
    let stream: MediaStream | null = null;

    // Gesture debounce state
    let gestureBuffer: string[] = [];
    let lastFiredGesture = '';
    let lastFiredTime = 0;
    const BUFFER_SIZE = 7;
    const CONFIRM_COUNT = 5;
    const COOLDOWN_MS = 1200;

    function countFingers(landmarks: any[], handLabel: string): number {
      let fingers = 0;
      // Thumb
      if (handLabel === 'Right') {
        if (landmarks[4].x < landmarks[3].x) fingers++;
      } else {
        if (landmarks[4].x > landmarks[3].x) fingers++;
      }
      // Index, Middle, Ring, Pinky
      if (landmarks[8].y  < landmarks[6].y)  fingers++;
      if (landmarks[12].y < landmarks[10].y) fingers++;
      if (landmarks[16].y < landmarks[14].y) fingers++;
      if (landmarks[20].y < landmarks[18].y) fingers++;
      return fingers;
    }

    function classifyGesture(handsLandmarks: any[], handedness: any[]): string {
      if (!handsLandmarks?.length) return 'Unknown';

      let totalFingers = 0;
      for (let i = 0; i < handsLandmarks.length; i++) {
        totalFingers += countFingers(handsLandmarks[i], handedness[i]?.label ?? 'Right');
      }

      const lm = handsLandmarks[0];

      // Special gestures (single hand, checked before finger count)
      // THUMB_UP: only thumb extended upward, all others folded
      if (
        lm[4].y < lm[2].y &&
        lm[8].y  > lm[6].y &&
        lm[12].y > lm[10].y &&
        lm[16].y > lm[14].y &&
        lm[20].y > lm[18].y
      ) return 'THUMB_UP';

      // THUMB_DOWN: only thumb extended downward
      if (
        lm[4].y > lm[2].y &&
        lm[8].y  > lm[6].y &&
        lm[12].y > lm[10].y &&
        lm[16].y > lm[14].y &&
        lm[20].y > lm[18].y
      ) return 'THUMB_DOWN';

      // OK: thumb tip close to index tip
      if (
        Math.abs(lm[4].x - lm[8].x) < 0.05 &&
        Math.abs(lm[4].y - lm[8].y) < 0.05
      ) return 'OK';

      // ROCK: index + pinky extended, middle + ring folded
      if (
        lm[8].y  < lm[6].y &&
        lm[20].y < lm[18].y &&
        lm[12].y > lm[10].y &&
        lm[16].y > lm[14].y
      ) return 'ROCK';

      // FIST: 0 fingers
      if (totalFingers === 0) return 'FIST';

      // Numeric
      if (totalFingers >= 1 && totalFingers <= 9) return String(totalFingers);

      return 'Unknown';
    }

    function fireGesture(raw: string) {
      if (!enabledRef.current) return;
      const now = Date.now();
      if (raw === lastFiredGesture && now - lastFiredTime < COOLDOWN_MS) return;
      lastFiredGesture = raw;
      lastFiredTime = now;

      let event: GestureEvent | null = null;

      if (raw === 'THUMB_UP')   event = { type: 'THUMB_UP' };
      else if (raw === 'THUMB_DOWN') event = { type: 'THUMB_DOWN' };
      else if (raw === 'FIST')  event = { type: 'FIST' };
      else if (raw === 'ROCK')  event = { type: 'ROCK' };
      else if (raw === 'OK')    event = { type: 'OK' };
      else if (/^[0-9]$/.test(raw)) {
        event = { type: 'DIGIT', value: raw };
        // Also emit GESTURE_ID if we have a mapping
        const gid = FINGER_TO_GESTURE_ID[raw];
        if (gid) {
          onGestureRef.current({ type: 'GESTURE_ID', id: gid });
        }
      }

      if (event) onGestureRef.current(event);
    }

    const init = async () => {
      try {
        stream = await navigator.mediaDevices.getUserMedia({ video: { width: 640, height: 480 } });
        if (cancelled) { stream.getTracks().forEach(t => t.stop()); return; }

        const video = videoRef.current!;
        video.srcObject = stream;
        await video.play();

        await new Promise<void>(res => {
          const poll = () => (video.videoWidth > 0 ? res() : setTimeout(poll, 80));
          poll();
        });
        if (cancelled) return;

        // Wait for MediaPipe CDN globals
        await new Promise<void>(res => {
          const poll = () => (typeof Hands !== 'undefined' ? res() : setTimeout(poll, 100));
          poll();
        });
        if (cancelled) return;

        handsInstance = new Hands({
          locateFile: (file: string) => `https://cdn.jsdelivr.net/npm/@mediapipe/hands/${file}`,
        });
        handsInstance.setOptions({
          maxNumHands: 2,
          modelComplexity: 0,
          minDetectionConfidence: 0.7,
          minTrackingConfidence: 0.7,
        });

        handsInstance.onResults((results: any) => {
          if (cancelled) return;
          const canvas = canvasRef.current;
          const video = videoRef.current;
          if (!canvas || !video) return;

          const ctx = canvas.getContext('2d')!;
          canvas.width  = video.videoWidth  || 640;
          canvas.height = video.videoHeight || 480;

          ctx.save();
          ctx.clearRect(0, 0, canvas.width, canvas.height);
          ctx.drawImage(video, 0, 0, canvas.width, canvas.height);

          if (results.multiHandLandmarks?.length > 0) {
            for (const lm of results.multiHandLandmarks) {
              drawConnectors(ctx, lm, HAND_CONNECTIONS, { color: '#00e676', lineWidth: 2 });
              drawLandmarks(ctx, lm, { color: '#7c3aed', lineWidth: 1, radius: 4 });
            }

            const raw = classifyGesture(results.multiHandLandmarks, results.multiHandedness ?? []);

            // Overlay gesture label
            ctx.fillStyle = '#fff';
            ctx.font = 'bold 16px system-ui';
            ctx.fillText(raw, 10, 24);

            // Buffer + debounce
            gestureBuffer.push(raw);
            if (gestureBuffer.length > BUFFER_SIZE) gestureBuffer.shift();
            const count = gestureBuffer.filter(g => g === raw).length;
            if (count >= CONFIRM_COUNT && raw !== 'Unknown') {
              fireGesture(raw);
            }
          } else {
            gestureBuffer = [];
          }
          ctx.restore();
        });

        const loop = async () => {
          if (cancelled) return;
          const v = videoRef.current;
          if (v && !v.paused && v.readyState >= 2) {
            try { await handsInstance.send({ image: v }); } catch (_) {}
          }
          animId = requestAnimationFrame(loop);
        };
        animId = requestAnimationFrame(loop);

      } catch (err) {
        console.error('GestureControl init error:', err);
      }
    };

    init();

    return () => {
      cancelled = true;
      cancelAnimationFrame(animId);
      stream?.getTracks().forEach(t => t.stop());
      handsInstance?.close?.();
    };
  }, []); // run once
}
