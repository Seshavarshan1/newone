import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { loginUser } from '../../api/authApi';
import './AdminLogin.css';

export default function AdminLogin() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      // Backend /api/auth/login looks up by user_id (primary key).
      // Admin username is 'admin' but user_id is 'U000' — pass user_id directly.
      const userId = username === 'admin' ? 'U000' : username;
      const res = await loginUser(userId);
      // Decode role from JWT payload
      const payload = JSON.parse(atob(res.token.split('.')[1]));
      const role: string = (payload.role || payload.authorities || '').toString().toLowerCase();
      if (!role.includes('admin')) { setError('Access denied: not an admin'); return; }
      login(
        { userId: 'U000', username: 'admin', email: 'admin@signbank.com', roleId: 'R000', roleName: 'admin', createdAt: '' },
        res.token
      );
      navigate('/admin/dashboard');
    } catch {
      setError('Invalid credentials');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="admin-login-page">
      <div className="admin-login-header">
        <button className="back-link" onClick={() => navigate('/')}>← Back</button>
        <div className="brand-center">
          <div className="brand-name">SignBank Enterprise</div>
          <div className="brand-tagline">Gesture Driven Smart Interaction Platform</div>
        </div>
        <div />
      </div>
      <div className="admin-login-content">
        <div className="admin-login-card">
          <h2>Admin Login</h2>
          <p className="login-hint">Enter your credentials to continue</p>
          <form onSubmit={handleSubmit}>
            <div className="field-group">
              <label>Username</label>
              <input type="text" placeholder="Enter your username" value={username} onChange={e => setUsername(e.target.value)} />
            </div>
            <div className="field-group">
              <label>Password</label>
              <input type="password" placeholder="Enter your password" value={password} onChange={e => setPassword(e.target.value)} />
            </div>
            {error && <p className="error-msg">{error}</p>}
            <button type="submit" className="sign-in-btn" disabled={loading}>
              {loading ? 'Signing in…' : 'Sign In'}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
