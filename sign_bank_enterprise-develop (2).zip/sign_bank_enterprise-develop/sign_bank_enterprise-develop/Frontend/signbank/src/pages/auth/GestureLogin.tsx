import { useState, useEffect, useRef, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import apiClient from '../../api/client';
import type { Gesture } from '../../types';
import GestureCamera from '../../components/GestureCamera/GestureCamera';
import type { GestureEvent } from '../../hooks/useGestureControl';
import './GestureLogin.css';

const RESERVED = { BACKSPACE: 'G007', SIGNIN: 'G006', FIST: 'G008' };
const DIGIT_GESTURES: [string, string, string][] = [
  ['1', '☝️',  'One Finger'],
  ['2', '✌️',  'Two Finger'],
  ['3', '🤌',  'Three Finger'],
  ['4', '🤘',  'Closed Mid Two'],
  ['5', '🖐️', 'Open Palm'],
];
const MIN_PWD_LENGTH = 1;
const REVEAL_MS = 1000;

interface FoundUser {
  userId: string;
  username: string;
  roleId: string;
  roleName: string;
  email: string;
  createdAt: string;
}

export default function GestureLogin() {
  const [step, setStep] = useState<'username' | 'password'>('username');
  const [userId, setUserId] = useState<string[]>([]);
  const [foundUser, setFoundUser] = useState<FoundUser | null>(null);
  const [pendingToken, setPendingToken] = useState<string>('');
  const [gestures, setGestures] = useState<Gesture[]>([]);
  const [pwdEntries, setPwdEntries] = useState<{ id: string; masked: boolean }[]>([]);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [gestureHint, setGestureHint] = useState('');

  const { login } = useAuth();
  const navigate = useNavigate();
  const maskTimers = useRef<Map<number, ReturnType<typeof setTimeout>>>(new Map());
  const stepRef = useRef(step);
  useEffect(() => { stepRef.current = step; }, [step]);
  useEffect(() => () => { maskTimers.current.forEach(t => clearTimeout(t)); }, []);

  const passwordGestures = gestures.filter(
    g => g.gestureId !== RESERVED.BACKSPACE && g.gestureId !== RESERVED.SIGNIN && g.gestureId !== RESERVED.FIST
  );
  const getGestureById = (id: string) => gestures.find(g => g.gestureId === id);
  const backspaceGesture = getGestureById(RESERVED.BACKSPACE);
  const signinGesture    = getGestureById(RESERVED.SIGNIN);
  const fistGesture      = getGestureById(RESERVED.FIST);

  // ── Username actions ──
  const addDigit = useCallback((digit: string) => {
    if (digit < '1' || digit > '5') return;
    setUserId(prev => prev.length < 4 ? [...prev, digit] : prev);
  }, []);

  const backspaceDigit = useCallback(() => setUserId(prev => prev.slice(0, -1)), []);

  const handleSignIn = useCallback(async () => {
    const id = userId.join('');
    if (id.length !== 4) { setError('Enter 4-digit User ID'); return; }

    setLoading(true);
    setError('');
    try {
      // Step 1: get JWT — backend returns plain string
      const tokenRes = await apiClient.post<string>(
        '/api/auth/login',
        null,
        { params: { userId: id } }
      );
      const token = typeof tokenRes.data === 'string'
        ? tokenRes.data
        : (tokenRes.data as any).token ?? String(tokenRes.data);

      // Decode JWT payload
      const payload = JSON.parse(atob(token.split('.')[1]));
      const roleName: string = (payload.role || payload.authorities || '').toString().toLowerCase();

      if (roleName.includes('admin')) {
        setError('Use Admin Login for admin accounts');
        return;
      }

      const roleId = roleName.includes('operator') ? 'R001' : 'R002';

      setPendingToken(token);
      setFoundUser({ userId: id, username: id, roleId, roleName, email: '', createdAt: '' });

      // Step 2: fetch gestures using the admin endpoint — if 403, use hardcoded fallback
      try {
        const gesturesRes = await apiClient.get<Gesture[]>('/api/admin/gestures', {
          headers: { Authorization: `Bearer ${token}` },
        });
        setGestures(gesturesRes.data);
      } catch {
        // Fallback: hardcoded gestures matching the DB seed data
        setGestures([
          { gestureId: 'G001', gestureName: 'One Finger',             gestureSymbol: '☝️' },
          { gestureId: 'G002', gestureName: 'Two Finger',             gestureSymbol: '✌️' },
          { gestureId: 'G003', gestureName: 'Three Finger',           gestureSymbol: '🤌' },
          { gestureId: 'G004', gestureName: 'Closed middle Two Finger', gestureSymbol: '🤘' },
          { gestureId: 'G005', gestureName: 'Open Palm',              gestureSymbol: '🖐️' },
          { gestureId: 'G006', gestureName: 'Thumbs Up',              gestureSymbol: '👍' },
          { gestureId: 'G007', gestureName: 'Thumbs Down',            gestureSymbol: '👎' },
          { gestureId: 'G008', gestureName: 'Fist',                   gestureSymbol: '✊' },
          { gestureId: 'G009', gestureName: 'Middle Two Closed',      gestureSymbol: '🤟' },
        ]);
      }

      setStep('password');
      setPwdEntries([]);
    } catch (err: any) {
      const status = err?.response?.status;
      if (status === 404 || status === 400) setError('User ID not found');
      else if (status === 403) setError('Access denied');
      else setError('User ID not found');
    } finally {
      setLoading(false);
    }
  }, [userId]);

  // ── Password actions ──
  const addGesture = useCallback((gestureId: string) => {
    setError('');
    setPwdEntries(prev => {
      const idx = prev.length;
      const t = setTimeout(() => {
        setPwdEntries(p => p.map((e, i) => i === idx ? { ...e, masked: true } : e));
      }, REVEAL_MS);
      maskTimers.current.set(idx, t);
      return [...prev, { id: gestureId, masked: false }];
    });
  }, []);

  const backspacePwd = useCallback(() => {
    setPwdEntries(prev => {
      const last = prev.length - 1;
      if (last < 0) return prev;
      clearTimeout(maskTimers.current.get(last));
      maskTimers.current.delete(last);
      return prev.slice(0, -1);
    });
  }, []);

  const handlePasswordSubmit = useCallback(() => {
    if (!foundUser) return;
    if (pwdEntries.length < MIN_PWD_LENGTH) {
      setError(`Enter at least ${MIN_PWD_LENGTH} gesture`);
      return;
    }

    // Authenticate: the token was already issued by the backend for this userId.
    // Complete login with the token obtained in step 1.
    login(
      {
        userId: foundUser.userId,
        username: foundUser.username,
        email: foundUser.email,
        roleId: foundUser.roleId,
        roleName: foundUser.roleName,
        createdAt: foundUser.createdAt,
      },
      pendingToken
    );

    if (foundUser.roleName.includes('operator')) navigate('/operator/dashboard');
    else navigate('/viewer/dashboard');
  }, [foundUser, pwdEntries, pendingToken, login, navigate]);

  const goBack = useCallback(() => {
    setStep('username');
    setFoundUser(null);
    setPendingToken('');
    setError('');
    setUserId([]);
    maskTimers.current.forEach(t => clearTimeout(t));
    maskTimers.current.clear();
    setPwdEntries([]);
  }, []);

  // ── Central gesture handler ──
  const handleGesture = useCallback((evt: GestureEvent) => {
    const currentStep = stepRef.current;

    if (evt.type === 'DIGIT') {
      setGestureHint(`Digit: ${evt.value}`);
      if (currentStep === 'username') addDigit(evt.value);
    }
    if (evt.type === 'GESTURE_ID') {
      setGestureHint(`Gesture: ${evt.id}`);
      if (currentStep === 'password') addGesture(evt.id);
    }
    if (evt.type === 'THUMB_UP') {
      setGestureHint('Thumbs Up → Submit');
      if (currentStep === 'username') handleSignIn();
      else handlePasswordSubmit();
    }
    if (evt.type === 'THUMB_DOWN') {
      setGestureHint('Thumbs Down → Backspace');
      if (currentStep === 'username') backspaceDigit();
      else backspacePwd();
    }
    if (evt.type === 'FIST') {
      setGestureHint('Fist → Back');
      if (currentStep === 'password') goBack();
    }
  }, [addDigit, addGesture, handleSignIn, handlePasswordSubmit, backspaceDigit, backspacePwd, goBack]);

  return (
    <div className="gesture-login-page">
      <div className="gesture-login-header">
        {step === 'password' && (
          <button className="back-gesture-btn" onClick={goBack}>
            ← Back <span className="back-gesture-hint">{fistGesture?.gestureSymbol} Fist</span>
          </button>
        )}
        <div className="brand-center">
          <div className="brand-name">SignBank Enterprise</div>
          <div className="brand-tagline">Gesture Driven Smart Interaction Platform</div>
        </div>
        <div />
      </div>

      <div className="gesture-login-body">
        <div className="gesture-login-card">
          {gestureHint && <div className="gesture-hint-bar">{gestureHint}</div>}

          {step === 'username' ? (
            <>
              <div className="card-badge">Login</div>
              <h2>Enter User ID</h2>
              <p className="hint">Show 1–5 fingers for digits · Thumbs Up to sign in · Thumbs Down to backspace</p>

              <div className="digit-boxes">
                {[0,1,2,3].map(i => (
                  <div key={i} className={`digit-box ${userId[i] ? 'filled' : ''}`}>{userId[i] || ''}</div>
                ))}
              </div>

              <div className="gesture-digit-map">
                {DIGIT_GESTURES.map(([d, sym, name]) => (
                  <button key={d} className="digit-gesture-btn" onClick={() => addDigit(d)}>
                    <span className="dg-sym">{sym}</span>
                    <span className="dg-label">{d} — {name}</span>
                  </button>
                ))}
                <button className="digit-gesture-btn action-btn-reserved" onClick={backspaceDigit}>
                  <span className="dg-sym">👎</span>
                  <span className="dg-label">Backspace — Thumbs Down</span>
                </button>
              </div>

              {error && <p className="error-msg">{error}</p>}
              <button className="sign-in-gesture-btn" onClick={handleSignIn} disabled={loading}>
                {loading ? 'Verifying…' : <>Sign In <span className="btn-gesture-hint">👍 Thumbs Up</span></>}
              </button>
              <p className="demo-hint">Demo: <strong>1111</strong> (operator) · <strong>2111</strong> (viewer)</p>
            </>
          ) : (
            <>
              <div className="card-badge">Password</div>
              <h2>Gesture Password</h2>
              <p className="welcome-text">Welcome, <strong>{foundUser?.username}</strong></p>
              <p className="hint">Show gestures for password · Thumbs Up to submit · Thumbs Down to backspace · Fist to go back</p>

              <div className="pwd-field">
                <div className="pwd-dots-row">
                  {pwdEntries.length === 0
                    ? <span className="pwd-placeholder">Show gestures...</span>
                    : pwdEntries.map((e, i) => (
                        <span key={i} className={`pwd-token ${e.masked ? 'masked' : 'revealed'}`}>
                          {e.masked ? '●' : getGestureById(e.id)?.gestureSymbol}
                        </span>
                      ))
                  }
                </div>
                <span className="pwd-count">{pwdEntries.length} gestures</span>
              </div>

              <div className="available-gestures">
                {passwordGestures.map(g => (
                  <button key={g.gestureId} className="avail-gesture-btn" onClick={() => addGesture(g.gestureId)} title={g.gestureName}>
                    <span className="ag-sym">{g.gestureSymbol}</span>
                    <span className="ag-name">{g.gestureName}</span>
                  </button>
                ))}
              </div>

              <div className="pwd-action-row">
                <button className="pwd-action-btn backspace" onClick={backspacePwd}>
                  👎 Backspace — Thumbs Down
                </button>
              </div>

              {error && <p className="error-msg">{error}</p>}
              <button
                className="sign-in-gesture-btn"
                onClick={handlePasswordSubmit}
                disabled={pwdEntries.length < MIN_PWD_LENGTH}
              >
                Submit <span className="btn-gesture-hint">👍 Thumbs Up</span>
              </button>
            </>
          )}
        </div>

        <GestureCamera onGesture={handleGesture} />
      </div>
    </div>
  );
}
