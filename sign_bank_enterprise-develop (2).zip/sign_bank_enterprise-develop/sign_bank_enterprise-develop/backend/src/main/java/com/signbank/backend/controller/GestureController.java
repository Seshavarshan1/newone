package com.signbank.backend.controller;

import com.signbank.backend.dto.request.GestureEventRequest;
import com.signbank.backend.dto.response.GestureEventResponse;
import com.signbank.backend.service.GestureService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/gesture-events")
public class GestureController {

    private final GestureService gestureService;

    public GestureController(GestureService gestureService) {
        this.gestureService = gestureService;
    }

    @PostMapping
    public GestureEventResponse handleGesture(
            @RequestBody GestureEventRequest request) {
        return gestureService.handleGesture(request);
    }
}

