package com.signbank.backend.service;

import com.signbank.backend.dto.*;
import com.signbank.backend.dto.request.CommandRequest;
import com.signbank.backend.dto.request.GestureRequest;
import com.signbank.backend.dto.request.PageRequest;
import com.signbank.backend.entity.*;
import com.signbank.backend.mapper.AdminMapper;
import com.signbank.backend.repository.*;
import org.springframework.stereotype.Service;

import java.util.List;
import org.springframework.transaction.annotation.Transactional;

@Service
public class AdminService {

    private final RoleRepository roleRepo;
    private final UserRepository userRepo;
    private final GestureRepository gestureRepo;
    private final PageRepository pageRepo;
    private final CommandRepository commandRepo;
    private final CommandMappingRepository mappingRepo;

    public AdminService(
            RoleRepository roleRepo,
            UserRepository userRepo,
            GestureRepository gestureRepo,
            PageRepository pageRepo,
            CommandRepository commandRepo,
            CommandMappingRepository mappingRepo
    ) {
        this.roleRepo = roleRepo;
        this.userRepo = userRepo;
        this.gestureRepo = gestureRepo;
        this.pageRepo = pageRepo;
        this.commandRepo = commandRepo;
        this.mappingRepo = mappingRepo;
    }

    public List<Role> getRoles() {
        return roleRepo.findAll();
    }

    public List<UserResponse> getUsers() {
        return userRepo.findAll()
                .stream()
                .map(AdminMapper::toUserResponse)
                .toList();
    }

    public List<GestureResponse> getGestures() {
        return gestureRepo.findAll()
                .stream()
                .map(AdminMapper::toGestureResponse)
                .toList();
    }

    public List<Page> getPages() {
        return pageRepo.findAll();
    }

    public List<Command> getCommands() {
        return commandRepo.findAll();
    }

    public List<CommandMappingResponse> getMappings() {
        return mappingRepo.findAll()
                .stream()
                .map(AdminMapper::toMappingResponse)
                .toList();
    }

    @Transactional
    public UserResponse createUser(UserCreateRequest request) {

        Role role = roleRepo.findById(request.getRoleId())
                .orElseThrow(() -> new RuntimeException("Role not found"));

        User user = new User();
        user.setUserId(request.getUserId());
        user.setUsername(request.getUsername());
        user.setEmail(request.getEmail());
        user.setRole(role);
        user.setCreatedAt(java.time.LocalDateTime.now());

        if ("R000".equals(role.getRoleId())) {
            // ADMIN
            user.setPasswordHash(request.getPasswordHash());
            user.setGestureHash(null);
        } else {
            // OPERATOR / VIEWER
            user.setGestureHash(request.getGestureHash());
            user.setPasswordHash(null);
        }

        User saved = userRepo.save(user);
        return AdminMapper.toUserResponse(saved);
    }
    
    @Transactional
    public UserResponse updateUser(String id, UserCreateRequest request) {
        User user = userRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("User not found"));

        Role role = roleRepo.findById(request.getRoleId())
                .orElseThrow(() -> new RuntimeException("Role not found"));

        user.setUsername(request.getUsername());
        user.setEmail(request.getEmail());
        user.setRole(role);

        return AdminMapper.toUserResponse(userRepo.save(user));
    }

    @Transactional
    public void deleteUser(String id) {
        userRepo.deleteById(id);
    }
    
    @Transactional
    public CommandMappingResponse createMapping(CommandMappingRequest request) {

        Command command = commandRepo.findById(request.getCommandId())
                .orElseThrow(() -> new RuntimeException("Command not found"));

        Gesture gesture = gestureRepo.findById(request.getGestureId())
                .orElseThrow(() -> new RuntimeException("Gesture not found"));

        Role role = roleRepo.findById(request.getRoleId())
                .orElseThrow(() -> new RuntimeException("Role not found"));

        User user = null;
        if (request.getUserId() != null) {
            user = userRepo.findById(request.getUserId())
                    .orElseThrow(() -> new RuntimeException("User not found"));
        }

        CommandMapping mapping = new CommandMapping();
        mapping.setMapId(request.getMapId());
        mapping.setCommand(command);
        mapping.setGesture(gesture);
        mapping.setRole(role);
        mapping.setUser(user);
        mapping.setIsActive(request.getIsActive());

        CommandMapping saved = mappingRepo.save(mapping);
        return AdminMapper.toMappingResponse(saved);
    }
    
    @Transactional
    public GestureResponse createGesture(GestureRequest request) {

        Gesture gesture = new Gesture();

        gesture.setGestureId("G" + System.currentTimeMillis());

        gesture.setGestureName(request.getGestureName());
        gesture.setGestureSymbol(request.getGestureSymbol());

        return AdminMapper.toGestureResponse(gestureRepo.save(gesture));
    }
    
    @Transactional
    public GestureResponse updateGesture(String id, GestureRequest request) {

        Gesture gesture = gestureRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("Gesture not found"));

        gesture.setGestureName(request.getGestureName());
        gesture.setGestureSymbol(request.getGestureSymbol());

        Gesture updated = gestureRepo.save(gesture);

        return AdminMapper.toGestureResponse(updated);
    }
    
    @Transactional
    public void deleteGesture(String id) {
        gestureRepo.deleteById(id);
    }

    @Transactional
    public CommandMappingResponse updateMapping(String mapId, CommandMappingRequest request) {

        CommandMapping mapping = mappingRepo.findById(mapId)
                .orElseThrow(() -> new RuntimeException("Mapping not found"));

        Gesture gesture = gestureRepo.findById(request.getGestureId())
                .orElseThrow(() -> new RuntimeException("Gesture not found"));

        mapping.setGesture(gesture);

        if (request.getIsActive() != null) {
            mapping.setIsActive(request.getIsActive());
        }

        return AdminMapper.toMappingResponse(mappingRepo.save(mapping));
    }
    
    @Transactional
    public void updateMappingStatus(String mapId, Boolean active) {

        CommandMapping mapping = mappingRepo.findById(mapId)
                .orElseThrow(() -> new RuntimeException("Mapping not found"));

        mapping.setIsActive(active);

        mappingRepo.save(mapping);
    }
    
    @Transactional
    public void deleteMapping(String mapId) {
        mappingRepo.deleteById(mapId);
    }
    
    @Transactional
    public Command createCommand(CommandRequest request) {
        Page page = pageRepo.findById(request.getPageId())
                .orElseThrow(() -> new RuntimeException("Page not found"));

        Command command = new Command();
        command.setCommandId("CMD" + System.currentTimeMillis());
        command.setCommandName(request.getCommandName());
        command.setCommandDescription(request.getCommandDescription());
        command.setPage(page);

        return commandRepo.save(command);
    }

    @Transactional
    public Command updateCommand(String id, CommandRequest request) {
        Command command = commandRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("Command not found"));

        Page page = pageRepo.findById(request.getPageId())
                .orElseThrow(() -> new RuntimeException("Page not found"));

        command.setCommandName(request.getCommandName());
        command.setCommandDescription(request.getCommandDescription());
        command.setPage(page);

        return commandRepo.save(command);
    }

    @Transactional
    public void deleteCommand(String id) {
        commandRepo.deleteById(id);
    }
    
    @Transactional
    public Page createPage(PageRequest request) {
        Role role = roleRepo.findById(request.getRoleId())
                .orElseThrow(() -> new RuntimeException("Role not found"));

        Page page = new Page();
        page.setPageId("P" + System.currentTimeMillis());
        page.setPageName(request.getPageName());
        page.setRole(role);

        return pageRepo.save(page);
    }
    
    
    
    @Transactional
    public Page updatePage(String id, PageRequest request) {
        Page page = pageRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("Page not found"));

        Role role = roleRepo.findById(request.getRoleId())
                .orElseThrow(() -> new RuntimeException("Role not found"));

        page.setPageName(request.getPageName());
        page.setRole(role);

        return pageRepo.save(page);
    }

    @Transactional
    public void deletePage(String id) {
        pageRepo.deleteById(id);
    }

}
