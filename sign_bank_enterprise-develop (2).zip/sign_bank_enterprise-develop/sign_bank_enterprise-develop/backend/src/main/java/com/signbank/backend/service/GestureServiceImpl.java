package com.signbank.backend.service;


import com.signbank.backend.dto.request.GestureEventRequest;
import com.signbank.backend.dto.response.GestureEventResponse;
import com.signbank.backend.entity.CommandMapping;
import com.signbank.backend.entity.Gesture;
import com.signbank.backend.exception.GestureMappingNotFoundException;
import com.signbank.backend.exception.GestureNotFoundException;
import com.signbank.backend.exception.LowConfidenceException;
import com.signbank.backend.repository.CommandMappingRepository;
import com.signbank.backend.repository.GestureRepository;
import org.springframework.stereotype.Service;

@Service
public class GestureServiceImpl implements GestureService {

    private final GestureRepository gestureRepository;
    private final CommandMappingRepository commandMappingRepository;

    public GestureServiceImpl(GestureRepository gestureRepository,
                              CommandMappingRepository commandMappingRepository) {
        this.gestureRepository = gestureRepository;
        this.commandMappingRepository = commandMappingRepository;
    }

    @Override
    public GestureEventResponse handleGesture(GestureEventRequest request) {

        if (request.getConfidence() < 0.8) {
            throw new LowConfidenceException("Gesture confidence too low");
        }

        Gesture gesture = gestureRepository
                .findByGestureName(request.getGestureCode())
                .orElseThrow(() ->
                        new GestureNotFoundException("Gesture not found"));

        String roleId = "R001"; // TEMP: Operator role (replace with auth later)

        CommandMapping mapping =
                commandMappingRepository
                        .findByGesture_GestureIdAndRole_RoleId(
                                gesture.getGestureId(), roleId
                        )
                        .orElseThrow(() ->
                                new GestureMappingNotFoundException("No mapping found"));

        return GestureEventResponse.success(
                mapping.getCommand().getCommandName()
        );
    }
}
