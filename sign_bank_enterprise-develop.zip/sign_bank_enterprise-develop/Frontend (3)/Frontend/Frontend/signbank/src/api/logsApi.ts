/**
 * Logs & Analytics API
 * POST /api/logs
 * GET  /api/logs
 * GET  /api/logs/detailed
 * GET  /api/logs/user/{userId}
 * GET  /api/logs/filter
 * GET  /api/logs/analytics
 */
import apiClient from './client';
import type { InteractionLog } from '../types';

export const fetchLogs = (): Promise<InteractionLog[]> =>
  apiClient.get('/api/logs').then(r => r.data);

export const fetchDetailedLogs = (): Promise<InteractionLog[]> =>
  apiClient.get('/api/logs/detailed').then(r => r.data);

export const fetchLogsByUser = (userId: string): Promise<InteractionLog[]> =>
  apiClient.get(`/api/logs/user/${userId}`).then(r => r.data);

export const fetchFilteredLogs = (params: Record<string, string>): Promise<InteractionLog[]> =>
  apiClient.get('/api/logs/filter', { params }).then(r => r.data);

export const fetchAnalytics = (): Promise<Record<string, unknown>> =>
  apiClient.get('/api/logs/analytics').then(r => r.data);

export const postLog = (payload: Omit<InteractionLog, 'interaction_id'>): Promise<InteractionLog> =>
  apiClient.post('/api/logs', payload).then(r => r.data);
