import { useState, useEffect, useRef, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { useData } from '../../context/DataContext';
import GestureCamera from '../../components/GestureCamera/GestureCamera';
import type { GestureEvent } from '../../hooks/useGestureControl';
import apiClient from '../../api/client';
import './SetPassword.css';

const MIN_PWD_LENGTH = 3;
const REVEAL_MS = 1000;
const RESERVED = { BACKSPACE: 'G007', SIGNIN: 'G006', FIST: 'G008' };
type Entry = { id: string; masked: boolean };

const ROLE_ROUTES: Record<string, string> = {
  R001: '/operator/dashboard',
  R002: '/viewer/dashboard',
};

// Emoji fallbacks for gesture buttons
const ID_TO_EMOJI: Record<string, string> = {
  G001: '☝️', G002: '✌️', G003: '🤌', G004: '🤘',
  G005: '🖐️', G006: '👍', G007: '👎', G008: '✊', G009: '🤟',
};
const NAME_TO_EMOJI: Record<string, string> = {
  'One Finger': '☝️', ONE_FINGER: '☝️',
  'Two Finger': '✌️', TWO_FINGER: '✌️',
  'Three Finger': '🤌', THREE_FINGER: '🤌',
  'Closed middle Two Finger': '🤘', CLOSED_MIDDLE_TWO_FINGER: '🤘',
  'Open Palm': '🖐️', OPEN_PALM: '🖐️',
  'Thumbs Up': '👍', THUMBS_UP: '👍',
  'Thumbs Down': '👎', THUMBS_DOWN: '👎',
  'Fist': '✊', FIST: '✊',
  'Middle Two Closed': '🤟', MIDDLE_TWO_CLOSED: '🤟',
};
function resolveEmoji(g: { gestureId: string; gestureName: string; gestureSymbol: string }): string {
  const s = g.gestureSymbol;
  if (s && /\p{Emoji}/u.test(s)) return s;
  return ID_TO_EMOJI[g.gestureId] ?? NAME_TO_EMOJI[g.gestureName] ?? '🤚';
}

export default function SetPassword() {
  const { currentUser, login, token } = useAuth();
  const { gestures } = useData();
  const navigate = useNavigate();

  // Filter out reserved gestures from password options
  const passwordGestures = gestures.filter(
    g => g.gestureId !== RESERVED.BACKSPACE &&
         g.gestureId !== RESERVED.SIGNIN &&
         g.gestureId !== RESERVED.FIST
  );
  const backspaceGesture = gestures.find(g => g.gestureId === RESERVED.BACKSPACE);
  const signinGesture    = gestures.find(g => g.gestureId === RESERVED.SIGNIN);
  const getGestureById   = (id: string) => gestures.find(g => g.gestureId === id);

  const [newEntries,     setNewEntries]     = useState<Entry[]>([]);
  const [confirmEntries, setConfirmEntries] = useState<Entry[]>([]);
  const [activeField,    setActiveField]    = useState<'new' | 'confirm'>('new');
  const [error,          setError]          = useState('');
  const [success,        setSuccess]        = useState(false);
  const [saving,         setSaving]         = useState(false);
  const [gestureHint,    setGestureHint]    = useState('');

  const newTimers     = useRef<Map<number, ReturnType<typeof setTimeout>>>(new Map());
  const confirmTimers = useRef<Map<number, ReturnType<typeof setTimeout>>>(new Map());
  const activeFieldRef = useRef(activeField);
  useEffect(() => { activeFieldRef.current = activeField; }, [activeField]);
  useEffect(() => () => {
    newTimers.current.forEach(t => clearTimeout(t));
    confirmTimers.current.forEach(t => clearTimeout(t));
  }, []);

  const addGesture = useCallback((gestureId: string) => {
    setError('');
    const field = activeFieldRef.current;
    if (field === 'new') {
      setNewEntries(prev => {
        const idx = prev.length;
        const t = setTimeout(() =>
          setNewEntries(p => p.map((e, i) => i === idx ? { ...e, masked: true } : e)), REVEAL_MS);
        newTimers.current.set(idx, t);
        return [...prev, { id: gestureId, masked: false }];
      });
    } else {
      setConfirmEntries(prev => {
        const idx = prev.length;
        const t = setTimeout(() =>
          setConfirmEntries(p => p.map((e, i) => i === idx ? { ...e, masked: true } : e)), REVEAL_MS);
        confirmTimers.current.set(idx, t);
        return [...prev, { id: gestureId, masked: false }];
      });
    }
  }, []);

  const backspace = useCallback(() => {
    const field = activeFieldRef.current;
    if (field === 'new') {
      setNewEntries(prev => {
        const last = prev.length - 1; if (last < 0) return prev;
        clearTimeout(newTimers.current.get(last)); newTimers.current.delete(last);
        return prev.slice(0, -1);
      });
    } else {
      setConfirmEntries(prev => {
        const last = prev.length - 1; if (last < 0) return prev;
        clearTimeout(confirmTimers.current.get(last)); confirmTimers.current.delete(last);
        return prev.slice(0, -1);
      });
    }
  }, []);

  const switchField = useCallback(() =>
    setActiveField(f => f === 'new' ? 'confirm' : 'new'), []);

  const handleSubmit = useCallback(() => {
    if (newEntries.length < MIN_PWD_LENGTH) {
      setError(`Minimum ${MIN_PWD_LENGTH} gestures required`); return;
    }
    if (confirmEntries.length === 0) {
      setError('Please confirm your password'); return;
    }

    const newSeq  = newEntries.map(e => e.id).join('-');
    const confSeq = confirmEntries.map(e => e.id).join('-');

    if (newSeq !== confSeq) {
      setError('Passwords do not match');
      confirmTimers.current.forEach(t => clearTimeout(t)); confirmTimers.current.clear();
      setConfirmEntries([]);
      return;
    }

    if (!currentUser) { setError('Session expired. Log in again.'); return; }

    setSaving(true);
    // Send gesture sequence as newPassword — backend BCrypt-hashes it into password_hash
    apiClient.post<string>('/api/auth/set-password', null, {
      params: { userId: currentUser.userId, newPassword: newSeq },
    })
    .then(res => {
      const newToken = typeof res.data === 'string' ? res.data.trim() : (token ?? '');
      // Update context: passwordSet = true, store real JWT
      login({ ...currentUser, passwordSet: true }, newToken);
      setSuccess(true);
      setTimeout(() => navigate(ROLE_ROUTES[currentUser.roleId] ?? '/'), 1500);
    })
    .catch(() => {
      setError('Failed to save password. Please try again.');
    })
    .finally(() => setSaving(false));
  }, [newEntries, confirmEntries, currentUser, login, token, navigate]);

  const handleGesture = useCallback((evt: GestureEvent) => {
    if (evt.type === 'GESTURE_ID') { setGestureHint(`Gesture: ${evt.id}`); addGesture(evt.id); }
    if (evt.type === 'THUMB_DOWN') { setGestureHint('👎 Backspace'); backspace(); }
    if (evt.type === 'THUMB_UP')   { setGestureHint('👍 Submit'); handleSubmit(); }
    if (evt.type === 'ROCK')       { setGestureHint('Switch field'); switchField(); }
    if (evt.type === 'FIST')       { setGestureHint('✊ Switch field'); switchField(); }
  }, [addGesture, backspace, handleSubmit, switchField]);

  const renderField = (entries: Entry[], field: 'new' | 'confirm', label: string) => (
    <div className="pwd-field-group">
      <label className={activeField === field ? 'active-label' : ''} onClick={() => setActiveField(field)}>
        {label}
        {activeField === field && <span className="editing-tag">● editing</span>}
        <span className="field-count">{entries.length} gestures</span>
      </label>
      <div className={`pwd-field ${activeField === field ? 'active' : ''}`}
        onClick={() => setActiveField(field)}>
        <div className="pwd-dots-row">
          {entries.length === 0
            ? <span className="pwd-placeholder">
                {field === 'new' ? 'Show gestures...' : 'Repeat same gestures...'}
              </span>
            : entries.map((e, i) => {
                const g = getGestureById(e.id);
                return (
                  <span key={i} className={`pwd-token ${e.masked ? 'masked' : 'revealed'}`}>
                    {e.masked ? '●' : resolveEmoji(g ?? { gestureId: e.id, gestureName: '', gestureSymbol: '' })}
                  </span>
                );
              })
          }
        </div>
      </div>
    </div>
  );

  return (
    <div className="set-password-page">
      <div className="set-pwd-header">
        <div className="brand-name">SignBank Enterprise</div>
        <div className="brand-tagline">Set Your Gesture Password</div>
      </div>
      <div className="set-pwd-body">
        <div className="set-pwd-card">
          <div className="card-badge first-login">First Login</div>
          <h2>Set Gesture Password</h2>
          <p className="hint">
            Welcome <strong>{currentUser?.username}</strong>.
            Show at least {MIN_PWD_LENGTH} gestures as your password.
            Fist / Rock gesture switches between New and Confirm fields.
          </p>

          {success ? (
            <div className="success-msg">✅ Password set! Redirecting...</div>
          ) : (
            <>
              {gestureHint && <div className="gesture-hint-bar">{gestureHint}</div>}

              {renderField(newEntries,     'new',     'New Password')}
              {renderField(confirmEntries, 'confirm', 'Confirm Password')}

              <div className="available-gestures">
                {passwordGestures.map(g => (
                  <button key={g.gestureId} className="avail-gesture-btn"
                    onClick={() => addGesture(g.gestureId)} title={g.gestureName}>
                    <span className="ag-sym">{resolveEmoji(g)}</span>
                    <span className="ag-name">{g.gestureName}</span>
                  </button>
                ))}
              </div>

              <div className="pwd-action-row">
                <button className="pwd-action-btn backspace" onClick={backspace}>
                  {resolveEmoji(backspaceGesture ?? { gestureId: 'G007', gestureName: 'Thumbs Down', gestureSymbol: '👎' })}
                  {' '}Backspace
                </button>
                <button className="pwd-action-btn clear" onClick={switchField}>
                  ⇄ Switch Field
                </button>
              </div>

              {error && <p className="error-msg">{error}</p>}

              <button
                className="sign-in-gesture-btn"
                onClick={handleSubmit}
                disabled={newEntries.length < MIN_PWD_LENGTH || saving}
              >
                {saving ? 'Saving…' : (
                  <>Set Password{' '}
                    <span className="btn-gesture-hint">
                      {resolveEmoji(signinGesture ?? { gestureId: 'G006', gestureName: 'Thumbs Up', gestureSymbol: '👍' })}
                      {' '}{signinGesture?.gestureName ?? 'Thumbs Up'}
                    </span>
                  </>
                )}
              </button>
            </>
          )}
        </div>
        <GestureCamera onGesture={handleGesture} />
      </div>
    </div>
  );
}