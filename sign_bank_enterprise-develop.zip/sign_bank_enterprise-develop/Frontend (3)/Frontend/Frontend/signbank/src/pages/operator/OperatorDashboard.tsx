import { useCallback, useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import PortalLayout from '../../components/Layout/PortalLayout';
import GestureCamera from '../../components/GestureCamera/GestureCamera';
import { useAuth } from '../../context/AuthContext';
import apiClient from '../../api/client';
import type { Command } from '../../types';
import type { GestureEvent } from '../../hooks/useGestureControl';
import './OperatorDashboard.css';

const FALLBACK_COMMANDS: Command[] = [
  { commandId: 'C001', commandName: 'Check Balance',         commandDescription: 'Check balance', page: { pageId: 'P001', pageName: 'Operator Dashboard' } },
  { commandId: 'C003', commandName: 'Set Transaction Limit', commandDescription: 'Move one finger left/right', page: { pageId: 'P001', pageName: 'Operator Dashboard' } },
];

export default function OperatorDashboard() {
  const { logout } = useAuth();
  const navigate   = useNavigate();

  const [commands, setCommands] = useState<Command[]>(FALLBACK_COMMANDS);

  // ✅ FIXED: run only once
  useEffect(() => {
    apiClient
      .get<Command[]>('/api/admin/commands')
      .then(r => setCommands(r.data))
      .catch(() => {
        console.log('Using fallback commands');
      });
  }, []);

  const dashCommands = commands.filter(
    c => c.page?.pageId === 'P001' && c.commandName.toLowerCase() !== 'logout'
  );

  const handleCommandClick = (commandName: string) => {
    if (commandName === 'Check Balance') {
      navigate('/operator/balance');
    }
    if (commandName === 'Set Transaction Limit') {
      navigate('/operator/set-limit');
    }
  };

  // ✅ CLEAN + CORRECT gesture handling
  const handleGesture = useCallback((evt: GestureEvent) => {
    if (evt.type === 'DIGIT') {
      if (evt.value === '1') {
        navigate('/operator/set-limit');
        return;
      }

      if (evt.value === '2') {
        navigate('/operator/balance');
        return;
      }

      if (evt.value === '3') {
        logout();
        navigate('/');
        return;
      }
    }

    if (evt.type === 'FIST') {
      logout();
      navigate('/');
    }

  }, [logout, navigate]);

  const cardAccents = ['#059669', '#7c3aed', '#2563eb'];
  const cardBgs     = ['#f0fdf4', '#faf5ff', '#eff6ff'];

  return (
    <PortalLayout title="Operator" subtitle="Dashboard">
      <div className="operator-dashboard">

        {/* LEFT SIDE */}
        <div className="commands-panel">
          <h2>Available Commands</h2>

          <div className="command-cards">
            {dashCommands.map((cmd, i) => (
              <div
                key={cmd.commandId}
                className="command-card"
                style={{
                  background: cardBgs[i % cardBgs.length],
                  borderLeft: `4px solid ${cardAccents[i % cardAccents.length]}`
                }}
                onClick={() => handleCommandClick(cmd.commandName)}
              >
                <div
                  className="cmd-dot"
                  style={{ background: cardAccents[i % cardAccents.length] }}
                />

                <div className="cmd-info">
                  <div className="cmd-name">{cmd.commandName}</div>

                  {/* ✅ FIXED UI TEXT */}
                  <div className="cmd-gesture">
                    {cmd.commandName === 'Set Transaction Limit' && (
                      <strong>☝️ 1 Finger → Set Transaction</strong>
                    )}
                    {cmd.commandName === 'Check Balance' && (
                      <strong>✌️ 2 Finger → Check Balance</strong>
                    )}
                  </div>
                </div>

                <div className="cmd-symbol">
                  {cmd.commandName === 'Set Transaction Limit' && '☝️'}
                  {cmd.commandName === 'Check Balance' && '✌️'}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* RIGHT SIDE (CAMERA) */}
        <GestureCamera onGesture={handleGesture} />

      </div>
    </PortalLayout>
  );
}