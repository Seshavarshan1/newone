import { useCallback, useEffect, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import GestureCamera from '../../components/GestureCamera/GestureCamera';
import { useAuth } from '../../context/AuthContext';
import { setTransactionLimit } from '../../api/gestureApi';
import type { GestureEvent, LandmarkPoint } from '../../hooks/useGestureControl';
import './OperatorSetLimit.css';

const MIN_LIMIT = 500;
const MAX_LIMIT = 100_000;

type SaveState = 'idle' | 'saving' | 'saved' | 'error';

/** Map normX (0..1, OpenCV-smoothed wrist X) → rupee limit */
function normToLimit(normX: number): number {
  const raw = Math.round(
    (MIN_LIMIT + normX * (MAX_LIMIT - MIN_LIMIT)) / 500
  ) * 500;
  return Math.max(MIN_LIMIT, Math.min(MAX_LIMIT, raw));
}

export default function OperatorSetLimit() {
  const { currentUser } = useAuth();
  const navigate        = useNavigate();
  const userId          = currentUser?.username ?? 'default';

  const [limit,        setLimit]        = useState(10_000);
  const [sliderActive, setSliderActive] = useState(false);
  const [sliderPct,    setSliderPct]    = useState(
    ((10_000 - MIN_LIMIT) / (MAX_LIMIT - MIN_LIMIT)) * 100
  );
  const [saveState,    setSaveState]    = useState<SaveState>('idle');
  const [errorMsg,     setErrorMsg]     = useState('');

  // Refs so gesture callback never has stale closures
  const limitRef     = useRef(limit);
  const saveStateRef = useRef<SaveState>('idle');
  useEffect(() => { limitRef.current    = limit;     }, [limit]);
  useEffect(() => { saveStateRef.current = saveState; }, [saveState]);

  // ── Save limit ────────────────────────────────────────────────────────────
  const doSave = useCallback(async () => {
    if (saveStateRef.current === 'saving' || saveStateRef.current === 'saved') return;
    const currentLimit = limitRef.current;
    setSaveState('saving');
    setErrorMsg('');
    try {
      await setTransactionLimit({ userId, limit: currentLimit });
      setSaveState('saved');
      setTimeout(() => navigate('/operator/dashboard'), 1800);
    } catch (e: any) {
      // Fallback: localStorage so session value is preserved
      try {
        localStorage.setItem(
          `signbank_limit_${userId}`,
          JSON.stringify({ userId, limit: currentLimit, savedAt: new Date().toISOString() })
        );
        setSaveState('saved');
        setTimeout(() => navigate('/operator/dashboard'), 1800);
      } catch (_) {
        setSaveState('error');
        setErrorMsg(
          e?.response?.data?.message ??
          'Backend unreachable. Check SecurityConfig.java — ' +
          'add /api/operator/** to permitted URLs.'
        );
      }
    }
  }, [userId, navigate]);

  // ── Gesture handler ───────────────────────────────────────────────────────
  const handleGesture = useCallback((evt: GestureEvent) => {
    switch (evt.type) {

      // Slider position update — fired every frame while ROCK is held
      case 'SLIDER_ACTIVE': {
        const newLimit = normToLimit(evt.normX);
        setLimit(newLimit);
        limitRef.current = newLimit;
        setSliderPct(((newLimit - MIN_LIMIT) / (MAX_LIMIT - MIN_LIMIT)) * 100);
        setSliderActive(true);
        break;
      }

      // ROCK released — exit slider mode
      case 'SLIDER_COMMIT':
        setSliderActive(false);
        break;

      // Confirm & save
      case 'THUMB_UP':
        doSave();
        break;

      // Go back
      case 'FIST':
        navigate('/operator/dashboard');
        break;

      case 'GESTURE_ID':
        if (evt.id === 'G003') navigate('/operator/dashboard');
        break;

      default:
        break;
    }
  }, [doSave, navigate]);

  // Landmarks streamed for optional backend use — noop here
  const handleLandmarks = useCallback((_lm: LandmarkPoint[]) => {}, []);

  const dirColor = sliderActive ? '#7c3aed' : '#94a3b8';

  return (
    <div className="setlimit-layout">

      <header className="setlimit-header">
        <button className="setlimit-back-btn" onClick={() => navigate('/operator/dashboard')}>
          ← Back <span className="gesture-hint">✊ Fist</span>
        </button>
        <div className="setlimit-brand">
          <span className="setlimit-title">Operator</span>
          <span className="setlimit-sub">Set Transaction Limit</span>
        </div>
        <div />
      </header>

      <main className="setlimit-main">
        <div className="setlimit-page">

          {/* ── Left panel ─────────────────────────────────────────────── */}
          <div className="setlimit-panel">

            <div className={`finger-hint ${sliderActive ? 'active' : ''}`}>
              {sliderActive
                ? '🤘 Slider active — move hand left / right to adjust'
                : '🤘 Hold ROCK gesture (~0.7 s) to activate the slider'}
            </div>

            <div className="limit-card">
              <div className="limit-label">Transaction Limit</div>
              <div className="limit-amount" style={{ color: dirColor }}>
                ₹ {limit.toLocaleString('en-IN')}.00
              </div>
              <div className="limit-user">Account: {userId}</div>

              <div
                className="direction-badge"
                style={{
                  background: dirColor + '22',
                  border: `1px solid ${dirColor}`,
                  color: dirColor,
                }}
              >
                {sliderActive
                  ? '← Move left to decrease · Move right to increase →'
                  : '— Hold 🤘 Rock to activate slider'}
              </div>

              {/* Progress bar + thumb */}
              <div className="limit-bar-track">
                <div
                  className="limit-bar-fill"
                  style={{ width: `${sliderPct}%`, background: dirColor }}
                />
                <div
                  className="limit-bar-thumb"
                  style={{ left: `calc(${sliderPct}% - 10px)`, background: dirColor }}
                />
              </div>
              <div className="limit-bar-labels">
                <span>₹{MIN_LIMIT.toLocaleString('en-IN')}</span>
                <span>₹{MAX_LIMIT.toLocaleString('en-IN')}</span>
              </div>
            </div>

            <div className="limit-details">
              <div className="detail-row">
                <span>Current Limit</span>
                <span style={{ color: dirColor }}>₹ {limit.toLocaleString('en-IN')}.00</span>
              </div>
              <div className="detail-row"><span>Min Allowed</span><span>₹ 500.00</span></div>
              <div className="detail-row"><span>Max Allowed</span><span>₹ 1,00,000.00</span></div>
              <div className="detail-row"><span>Account</span><span>{userId}</span></div>
            </div>

            <button
              className={`confirm-btn ${saveState}`}
              onClick={doSave}
              disabled={saveState === 'saving' || saveState === 'saved'}
            >
              {saveState === 'saving' ? '⏳ Saving…'
                : saveState === 'saved'  ? '✅ Saved!'
                : saveState === 'error'  ? '❌ Retry'
                : '👍 Confirm Limit (Thumb Up)'}
            </button>
            {saveState === 'error' && (
              <div className="error-msg">{errorMsg}</div>
            )}

            <div className="gesture-guide">
              <div className="guide-item"><span>🤘</span><span>Hold Rock to open slider</span></div>
              <div className="guide-item"><span>←→</span><span>Move hand left/right to adjust</span></div>
              <div className="guide-item"><span>👍</span><span>Thumb Up → Confirm &amp; Save</span></div>
              <div className="guide-item"><span>✊</span><span>Fist → Go Back</span></div>
            </div>
          </div>

          {/* ── Camera panel ─────────────────────────────────────────────── */}
          <GestureCamera
            onGesture={handleGesture}
            onLandmarks={handleLandmarks}
            sliderMode={true}
          />

        </div>
      </main>
    </div>
  );
}