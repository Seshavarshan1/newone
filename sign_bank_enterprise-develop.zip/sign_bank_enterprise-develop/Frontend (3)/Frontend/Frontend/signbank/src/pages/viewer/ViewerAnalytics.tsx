import { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import PortalLayout from '../../components/Layout/PortalLayout';
import GestureCamera from '../../components/GestureCamera/GestureCamera';
import { fetchLogsByUser } from '../../api/logsApi';
import { useAuth } from '../../context/AuthContext';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, Legend } from 'recharts';
import type { InteractionLog } from '../../types';
import type { GestureEvent } from '../../hooks/useGestureControl';
import './ViewerAnalytics.css';

const COLORS = ['#059669', '#ef4444'];

export default function ViewerAnalytics() {
  const { currentUser } = useAuth();
  const navigate = useNavigate();
  const [logs, setLogs] = useState<InteractionLog[]>([]);

  useEffect(() => {
    if (!currentUser) return;
    fetchLogsByUser(currentUser.userId).then(setLogs).catch(() => {});
  }, [currentUser]);

  const handleGesture = useCallback((evt: GestureEvent) => {
    if (evt.type === 'GESTURE_ID' && evt.id === 'G003') navigate('/viewer/dashboard');
  }, [navigate]);

  const total = logs.length;
  const success = logs.filter(l => l.status === 'success').length;
  const failed = logs.filter(l => l.status === 'failed').length;

  // Build gesture usage from nested gesture object
  const gestureMap = new Map<string, { name: string; count: number }>();
  logs.forEach(l => {
    if (!l.gesture) return;
    const key = l.gesture.gestureId;
    const existing = gestureMap.get(key);
    if (existing) existing.count++;
    else gestureMap.set(key, { name: l.gesture.gestureName, count: 1 });
  });
  const gestureUsage = Array.from(gestureMap.values());

  const statusData = [
    { name: 'Success', value: success },
    { name: 'Failed', value: failed },
  ].filter(d => d.value > 0);

  return (
    <PortalLayout title="Viewer" subtitle="Analytics" backPath="/viewer/dashboard" showLogout={false}>
      <div className="viewer-analytics-layout">
        <div className="analytics-content">
          <h2 style={{ marginBottom: 20, fontSize: 22, fontWeight: 700, color: '#1e293b' }}>My Analytics</h2>
          <div className="stat-row">
            <div className="mini-stat purple"><div className="ms-num">{total}</div><div className="ms-label">Total</div></div>
            <div className="mini-stat green"><div className="ms-num">{success}</div><div className="ms-label">Success</div></div>
            <div className="mini-stat red"><div className="ms-num">{failed}</div><div className="ms-label">Failed</div></div>
          </div>
          <div className="viewer-charts">
            <div className="chart-card">
              <h3>Gesture Usage</h3>
              {gestureUsage.length > 0 ? (
                <ResponsiveContainer width="100%" height={200}>
                  <BarChart data={gestureUsage}>
                    <XAxis dataKey="name" tick={{ fontSize: 10 }} />
                    <YAxis allowDecimals={false} />
                    <Tooltip />
                    <Bar dataKey="count" fill="#7c3aed" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              ) : <p className="no-data">No data yet</p>}
            </div>
            <div className="chart-card">
              <h3>Status</h3>
              {total > 0 ? (
                <ResponsiveContainer width="100%" height={200}>
                  <PieChart>
                    <Pie data={statusData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={70} label>
                      {statusData.map((_, i) => <Cell key={i} fill={COLORS[i]} />)}
                    </Pie>
                    <Legend /><Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              ) : <p className="no-data">No data yet</p>}
            </div>
          </div>
        </div>
        <GestureCamera onGesture={handleGesture} />
      </div>
    </PortalLayout>
  );
}
