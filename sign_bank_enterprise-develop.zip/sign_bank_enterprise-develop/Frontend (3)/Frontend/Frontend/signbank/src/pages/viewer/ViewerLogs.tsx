import { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import PortalLayout from '../../components/Layout/PortalLayout';
import GestureCamera from '../../components/GestureCamera/GestureCamera';
import { fetchLogsByUser } from '../../api/logsApi';
import { useAuth } from '../../context/AuthContext';
import type { InteractionLog } from '../../types';
import type { GestureEvent } from '../../hooks/useGestureControl';
import './ViewerLogs.css';

export default function ViewerLogs() {
  const { currentUser } = useAuth();
  const navigate = useNavigate();
  const [logs, setLogs] = useState<InteractionLog[]>([]);

  useEffect(() => {
    if (!currentUser) return;
    fetchLogsByUser(currentUser.userId).then(setLogs).catch(() => {});
  }, [currentUser]);

  const handleGesture = useCallback((evt: GestureEvent) => {
    if (evt.type === 'GESTURE_ID' && evt.id === 'G003') navigate('/viewer/dashboard');
  }, [navigate]);

  return (
    <PortalLayout title="Viewer" subtitle="Logs" backPath="/viewer/dashboard" showLogout={false}>
      <div className="viewer-logs-layout">
        <div className="logs-content">
          <h2 style={{ marginBottom: 20, fontSize: 22, fontWeight: 700, color: '#1e293b' }}>Interaction Logs</h2>
          <div className="table-card">
            <table className="logs-table">
              <thead>
                <tr><th>Log ID</th><th>Command</th><th>Gesture</th><th>Status</th><th>Time</th><th>Metadata</th></tr>
              </thead>
              <tbody>
                {logs.length === 0 ? (
                  <tr><td colSpan={6} className="empty-row">No logs found</td></tr>
                ) : logs.map(l => (
                  <tr key={l.interactionId}>
                    <td>{l.interactionId}</td>
                    <td>{l.command?.commandName ?? '—'}</td>
                    <td>{l.gesture ? `${l.gesture.gestureSymbol ?? ''} ${l.gesture.gestureName}` : '—'}</td>
                    <td><span className={`status-badge ${l.status}`}>{l.status}</span></td>
                    <td>{new Date(l.executedAt).toLocaleString()}</td>
                    <td>{l.metadata}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
        <GestureCamera onGesture={handleGesture} />
      </div>
    </PortalLayout>
  );
}
