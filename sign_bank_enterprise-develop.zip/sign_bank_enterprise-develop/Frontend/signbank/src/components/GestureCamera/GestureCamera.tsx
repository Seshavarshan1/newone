import { useRef, useState } from 'react';
import { useGestureControl, type GestureEvent } from '../../hooks/useGestureControl';
import './GestureCamera.css';

const GESTURE_EMOJI: Record<string, string> = {
  THUMB_UP:   '👍', THUMB_DOWN: '👎', FIST: '✊',
  ROCK:       '🤘', OK:         '👌', PINCH: '🤏',
  '1': '☝️', '2': '✌️', '3': '🤌', '4': '🤘', '5': '🖐️',
  G001: '☝️', G002: '✌️', G003: '🤌', G004: '🤘',
  G005: '🖐️', G006: '👍', G007: '👎', G008: '✊', G009: '🤟',
};

function getDisplayEmoji(evt: GestureEvent): string {
  if (evt.type === 'DIGIT')         return GESTURE_EMOJI[evt.value]  ?? `${evt.value}✋`;
  if (evt.type === 'GESTURE_ID')    return GESTURE_EMOJI[evt.id]     ?? '🤚';
  if (evt.type === 'HAND_POSITION') return evt.isPinched ? '🤏' : '🖐️';
  return GESTURE_EMOJI[evt.type] ?? '🤚';
}

function getDisplayLabel(evt: GestureEvent): string {
  if (evt.type === 'DIGIT')         return `${evt.value} finger${evt.value !== '1' ? 's' : ''}`;
  if (evt.type === 'GESTURE_ID')    return evt.id;
  if (evt.type === 'HAND_POSITION') return evt.isPinched ? 'pinched · dragging' : `pos ${(evt.normX * 100).toFixed(0)}%`;
  return evt.type.replace(/_/g, ' ').toLowerCase();
}

interface Props {
  onGesture?:         (event: GestureEvent) => void;
  onGestureDetected?: (name: string) => void;
  /** true = emit HAND_POSITION every frame + draw slider overlay on canvas */
  sliderMode?: boolean;
}

export default function GestureCamera({ onGesture, onGestureDetected, sliderMode = false }: Props) {
  const videoRef  = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [lastEvt,  setLastEvt]  = useState<GestureEvent | null>(null);
  const [active,   setActive]   = useState(false);
  const [isPinched, setIsPinched] = useState(false);

  useGestureControl(videoRef, canvasRef, {
    sliderMode,
    onGesture: (evt) => {
      if (evt.type === 'HAND_POSITION') {
        setActive(true);
        setIsPinched(evt.isPinched);
      } else {
        setLastEvt(evt);
        setActive(true);
      }

      onGesture?.(evt);
      if (onGestureDetected) {
        if (evt.type === 'DIGIT') onGestureDetected(evt.value);
        else if (evt.type !== 'HAND_POSITION') onGestureDetected(evt.type);
      }
    },
  });

  const emoji = lastEvt ? getDisplayEmoji(lastEvt) : null;
  const label = lastEvt ? getDisplayLabel(lastEvt) : null;

  return (
    <div className="gesture-camera">
      <div className="camera-header">
        <span className="camera-title">Live Gesture Detection</span>
        <span className={`status-dot ${active ? 'active' : 'loading'}`}>
          {active ? '● Active' : '● Loading'}
        </span>
      </div>

      <div className="camera-feed">
        <video ref={videoRef} className="camera-video" playsInline muted />
        <canvas ref={canvasRef} className="camera-canvas" />

        {/* Emoji badge — top-right of feed */}
        {emoji && !sliderMode && (
          <div className="gesture-emoji-badge">{emoji}</div>
        )}

        {/* Slider mode: show pinch status badge */}
        {sliderMode && (
          <div className={`pinch-status-badge ${isPinched ? 'pinched' : 'open'}`}>
            {isPinched ? '🤏 Dragging' : '🖐️ Show hand'}
          </div>
        )}
      </div>

      <div className="camera-prompt">
        {sliderMode
          ? isPinched
            ? '🤏 Pinched — move left/right to set amount · 👍 to lock'
            : '🖐️ Open palm to show slider · Pinch to drag'
          : 'Show a hand gesture to continue'}
      </div>

      <div className="ai-status">
        AI Detection:&nbsp;
        <span className={active ? 'ready' : 'not-ready'}>
          {active ? 'Ready' : 'Initializing'}
        </span>
        {!sliderMode && emoji && label && (
          <span className="detected-gesture">
            &nbsp;·&nbsp;{emoji}&nbsp;
            <span className="gesture-label-text">{label}</span>
          </span>
        )}
        {sliderMode && (
          <span className="detected-gesture">
            &nbsp;·&nbsp;
            <span className="gesture-label-text">
              {isPinched ? '🤏 pinch active' : 'pinch to drag'}
            </span>
          </span>
        )}
      </div>
    </div>
  );
}