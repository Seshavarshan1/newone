import { useEffect, useRef } from 'react';

//  Event types 
export type GestureEvent =
  | { type: 'DIGIT';         value: string }
  | { type: 'THUMB_UP' }
  | { type: 'THUMB_DOWN' }
  | { type: 'FIST' }
  | { type: 'ROCK' }
  | { type: 'OK' }
  | { type: 'GESTURE_ID';    id: string }
  | { type: 'SWIPE_LEFT' }
  | { type: 'SWIPE_RIGHT' }
  /**
   * Emitted every frame in sliderMode.
   * normX    : 0.0 (left edge) → 1.0 (right edge), already de-mirrored
   * isPinched: thumb+index close → user is "grabbing" the slider
   */
  | { type: 'HAND_POSITION'; normX: number; isPinched: boolean };

//  Gesture → GestureID map 
const FINGER_TO_GESTURE_ID: Record<string, string> = {
  '1': 'G001', '2': 'G002', '3': 'G003', '4': 'G004', '5': 'G005',
};

//  Canvas emoji map 
const RAW_TO_EMOJI: Record<string, string> = {
  THUMB_UP: '👍', THUMB_DOWN: '👎', FIST: '✊', ROCK: '🤘', OK: '👌',
  PINCH: '🤏',
  '0': '✊', '1': '☝️', '2': '✌️', '3': '🤌',
  '4': '🤘', '5': '🖐️', '6': '🖐️', '7': '🖐️',
};

//  Options 
export interface UseGestureControlOptions {
  onGesture:    (event: GestureEvent) => void;
  enabled?:     boolean;
  /**
   * sliderMode=true  →  emits HAND_POSITION every frame (pinch-to-drag)
   *                  →  draws the horizontal slider overlay on the canvas
   * sliderMode=false →  normal gesture detection
   */
  sliderMode?:  boolean;
}

declare const Hands: any;
declare const HAND_CONNECTIONS: any;
declare const drawConnectors: any;
declare const drawLandmarks: any;

//  Hook 
export function useGestureControl(
  videoRef:  React.RefObject<HTMLVideoElement | null>,
  canvasRef: React.RefObject<HTMLCanvasElement | null>,
  { onGesture, enabled = true, sliderMode = false }: UseGestureControlOptions
) {
  const onGestureRef   = useRef(onGesture);
  useEffect(() => { onGestureRef.current = onGesture; }, [onGesture]);

  const enabledRef     = useRef(enabled);
  useEffect(() => { enabledRef.current = enabled; }, [enabled]);

  const sliderModeRef  = useRef(sliderMode);
  useEffect(() => { sliderModeRef.current = sliderMode; }, [sliderMode]);

  useEffect(() => {
    let cancelled = false;
    let animId    = 0;
    let handsInstance: any  = null;
    let stream: MediaStream | null = null;

    // STABILITY: rolling buffer — a gesture only fires when it appears in
    // CONFIRM_COUNT out of the last BUFFER_SIZE frames AND the cooldown
    // has elapsed. This eliminates flickering false positives completely.
    const BUFFER_SIZE   = 18;   // frames examined
    const CONFIRM_COUNT = 14;   // must appear in 14/18 frames (~78 %)
    const COOLDOWN_MS   = 1800; // minimum ms between two fires of the SAME gesture
    let gestureBuffer: string[] = [];
    let lastFiredGesture = '';
    let lastFiredTime    = 0;

    //  Swipe 
    let prevPalmX: number | null = null;
    let lastSwipeTime = 0;
    const SWIPE_COOLDOWN  = 800;
    const SWIPE_THRESHOLD = 90; // px

    //  Smoothing: exponential moving average for wrist X position 
    // Used so the slider doesn't jitter frame to frame.
    let smoothNormX     = 0.5;
    const SMOOTH_ALPHA  = 0.18; // lower = smoother (but more lag); 0.18 is a good balance

    //  Pinch state 
    // Pinch = thumb tip (4) and index tip (8) close together.
    // We use a small hysteresis band so pinch doesn't flicker.
    let isPinchedState  = false;
    const PINCH_CLOSE   = 0.055; // normalised distance to enter pinch
    const PINCH_OPEN    = 0.075; // normalised distance to release pinch

    // GESTURE CLASSIFICATION
    function dist2D(a: any, b: any) {
      return Math.hypot(a.x - b.x, a.y - b.y);
    }

    function countFingers(lm: any[], handLabel: string): number {
      let n = 0;
      // Thumb
      if (handLabel === 'Right') { if (lm[4].x < lm[3].x) n++; }
      else                       { if (lm[4].x > lm[3].x) n++; }
      if (lm[8].y  < lm[6].y)  n++;
      if (lm[12].y < lm[10].y) n++;
      if (lm[16].y < lm[14].y) n++;
      if (lm[20].y < lm[18].y) n++;
      return n;
    }

    function classifyGesture(lmAll: any[], handedness: any[]): string {
      if (!lmAll?.length) return 'Unknown';

      let total = 0;
      for (let i = 0; i < lmAll.length; i++) {
        total += countFingers(lmAll[i], handedness[i]?.label ?? 'Right');
      }

      const lm = lmAll[0];

      // Pinch — thumb + index tips very close
      if (dist2D(lm[4], lm[8]) < PINCH_CLOSE) return 'PINCH';

      // Thumb up — thumb tip well above thumb IP, all fingers folded
      if (lm[4].y < lm[3].y - 0.05 &&
          lm[8].y  > lm[6].y  &&
          lm[12].y > lm[10].y &&
          lm[16].y > lm[14].y &&
          lm[20].y > lm[18].y) return 'THUMB_UP';

      // Thumb down
      if (lm[4].y > lm[3].y + 0.05 &&
          lm[8].y  > lm[6].y  &&
          lm[12].y > lm[10].y &&
          lm[16].y > lm[14].y &&
          lm[20].y > lm[18].y) return 'THUMB_DOWN';

      // OK — thumb + index tip very close (but not as tight as PINCH threshold)
      if (dist2D(lm[4], lm[8]) < 0.05) return 'OK';

      // Rock — index + pinky extended, middle + ring folded
      if (lm[8].y  < lm[6].y  &&
          lm[20].y < lm[18].y &&
          lm[12].y > lm[10].y &&
          lm[16].y > lm[14].y) return 'ROCK';

      if (total === 0) return 'FIST';
      if (total >= 1 && total <= 9) return String(total);
      return 'Unknown';
    }

    function fireGesture(raw: string) {
      if (!enabledRef.current) return;
      const now = Date.now();
      if (raw === lastFiredGesture && now - lastFiredTime < COOLDOWN_MS) return;
      lastFiredGesture = raw;
      lastFiredTime    = now;

      let ev: GestureEvent | null = null;
      if      (raw === 'THUMB_UP')   ev = { type: 'THUMB_UP' };
      else if (raw === 'THUMB_DOWN') ev = { type: 'THUMB_DOWN' };
      else if (raw === 'FIST')       ev = { type: 'FIST' };
      else if (raw === 'ROCK')       ev = { type: 'ROCK' };
      else if (raw === 'OK')         ev = { type: 'OK' };
      else if (/^[0-9]$/.test(raw)) {
        ev = { type: 'DIGIT', value: raw };
        const gid = FINGER_TO_GESTURE_ID[raw];
        if (gid) onGestureRef.current({ type: 'GESTURE_ID', id: gid });
      }
      if (ev) onGestureRef.current(ev);
    }

    
    // SLIDER OVERLAY DRAWING
    // Draws a clean horizontal line + dot that sits right at the hand's
    // vertical position. The dot follows the smoothed hand X.
    // When pinched the dot pulses and the line turns accent colour.
    
    function drawSliderOverlay(
      ctx: CanvasRenderingContext2D,
      smoothX: number,      // 0..1, already de-mirrored + smoothed
      palmY:   number,      // canvas px (raw)
      cw: number, ch: number,
      pinched: boolean
    ) {
      const PAD       = 40;
      const trackL    = PAD;
      const trackR    = cw - PAD;
      const trackLen  = trackR - trackL;
      const ty        = Math.min(Math.max(palmY, 50), ch - 50); // clamp vertical
      const thumbX    = trackL + smoothX * trackLen;

      ctx.save();

      //  Track background 
      ctx.globalAlpha = 0.45;
      ctx.strokeStyle = 'rgba(255,255,255,0.6)';
      ctx.lineWidth   = 4;
      ctx.lineCap     = 'round';
      ctx.beginPath();
      ctx.moveTo(trackL, ty);
      ctx.lineTo(trackR, ty);
      ctx.stroke();

      //  Filled segment (left → thumb) 
      ctx.globalAlpha = pinched ? 0.95 : 0.75;
      const grad = ctx.createLinearGradient(trackL, 0, trackR, 0);
      grad.addColorStop(0, '#059669');
      grad.addColorStop(1, '#7c3aed');
      ctx.strokeStyle = grad;
      ctx.lineWidth   = pinched ? 6 : 4;
      ctx.beginPath();
      ctx.moveTo(trackL,  ty);
      ctx.lineTo(thumbX,  ty);
      ctx.stroke();

      //  Thumb dot 
      // Outer glow ring when pinched
      if (pinched) {
        ctx.globalAlpha = 0.35;
        ctx.fillStyle   = '#7c3aed';
        ctx.beginPath();
        ctx.arc(thumbX, ty, 26, 0, Math.PI * 2);
        ctx.fill();
      }

      // White outer circle
      ctx.globalAlpha  = 1;
      ctx.shadowColor  = pinched ? 'rgba(124,58,237,0.9)' : 'rgba(0,0,0,0.4)';
      ctx.shadowBlur   = pinched ? 20 : 10;
      ctx.fillStyle    = '#ffffff';
      ctx.beginPath();
      ctx.arc(thumbX, ty, 16, 0, Math.PI * 2);
      ctx.fill();

      // Inner coloured dot
      ctx.shadowBlur  = 0;
      const inner = ctx.createRadialGradient(thumbX, ty, 0, thumbX, ty, 11);
      inner.addColorStop(0, pinched ? '#7c3aed' : '#059669');
      inner.addColorStop(1, pinched ? '#059669' : '#0ea5e9');
      ctx.fillStyle = inner;
      ctx.beginPath();
      ctx.arc(thumbX, ty, 11, 0, Math.PI * 2);
      ctx.fill();

      //  Min / Max tick labels on the track 
      ctx.globalAlpha = 0.65;
      ctx.fillStyle   = '#ffffff';
      ctx.font        = 'bold 11px system-ui';
      ctx.textAlign   = 'center';
      ctx.fillText('MIN', trackL,      ty - 14);
      ctx.fillText('MAX', trackR,      ty - 14);

      //  Pinch hint or value label above thumb 
      ctx.globalAlpha = 1;
      ctx.fillStyle   = pinched ? '#a78bfa' : '#ffffff';
      ctx.font        = `bold ${pinched ? 13 : 11}px system-ui`;
      ctx.textAlign   = 'center';
      const label = pinched ? '🤏 Dragging' : '🤏 Pinch to drag';
      ctx.fillText(label, thumbX, ty - 32);

      ctx.restore();
    }

    // MEDIAPIPE INIT
    const init = async () => {
      try {
        stream = await navigator.mediaDevices.getUserMedia({
          video: { width: 640, height: 480, facingMode: 'user' },
        });
        if (cancelled) { stream.getTracks().forEach(t => t.stop()); return; }

        const video = videoRef.current!;
        video.srcObject = stream;
        await video.play();

        // Wait for actual video dimensions
        await new Promise<void>(res => {
          const poll = () => video.videoWidth > 0 ? res() : setTimeout(poll, 80);
          poll();
        });
        if (cancelled) return;

        // Wait for MediaPipe globals
        await new Promise<void>(res => {
          const poll = () => typeof Hands !== 'undefined' ? res() : setTimeout(poll, 100);
          poll();
        });
        if (cancelled) return;

        handsInstance = new Hands({
          locateFile: (f: string) =>
            `https://cdn.jsdelivr.net/npm/@mediapipe/hands/${f}`,
        });
        handsInstance.setOptions({
          maxNumHands:            1,    // 1 hand = less confusion, faster
          modelComplexity:        1,
          minDetectionConfidence: 0.78,
          minTrackingConfidence:  0.78,
        });

        handsInstance.onResults((results: any) => {
          if (cancelled) return;
          const canvas = canvasRef.current;
          const video  = videoRef.current;
          if (!canvas || !video) return;

          const ctx = canvas.getContext('2d')!;
          canvas.width  = video.videoWidth  || 640;
          canvas.height = video.videoHeight || 480;

          ctx.save();
          ctx.clearRect(0, 0, canvas.width, canvas.height);
          ctx.drawImage(video, 0, 0, canvas.width, canvas.height);

          if (results.multiHandLandmarks?.length > 0) {
            const lm  = results.multiHandLandmarks[0];
            const now = Date.now();

            // Exponential smooth + de-mirror the wrist X 
            // MediaPipe gives 0=left, 1=right from camera's perspective.
            // Because video is CSS-mirrored we flip: user's right hand
            // should move slider right.
            const rawNormX   = 1 - lm[0].x;                           // de-mirror
            smoothNormX      = smoothNormX + SMOOTH_ALPHA * (rawNormX - smoothNormX); // EMA

            //  Pinch hysteresis 
            const pinchDist = dist2D(lm[4], lm[8]);
            if (!isPinchedState && pinchDist < PINCH_CLOSE) isPinchedState = true;
            if (isPinchedState  && pinchDist > PINCH_OPEN)  isPinchedState = false;

            //  SLIDER MODE 
            if (sliderModeRef.current) {
              // Emit position every frame (smoothed)
              onGestureRef.current({
                type:      'HAND_POSITION',
                normX:     smoothNormX,
                isPinched: isPinchedState,
              });

              // Draw slider overlay at the hand's vertical position
              const palmY = lm[0].y * canvas.height;
              drawSliderOverlay(
                ctx, smoothNormX, palmY,
                canvas.width, canvas.height,
                isPinchedState
              );
            }

            //  SWIPE (only outside slider mode) 
            if (!sliderModeRef.current) {
              const palmX = lm[0].x * canvas.width;
              if (prevPalmX !== null && now - lastSwipeTime > SWIPE_COOLDOWN) {
                const diff = palmX - prevPalmX;
                if (diff > SWIPE_THRESHOLD) {
                  onGestureRef.current({ type: 'SWIPE_RIGHT' });
                  lastSwipeTime = now; prevPalmX = null;
                } else if (diff < -SWIPE_THRESHOLD) {
                  onGestureRef.current({ type: 'SWIPE_LEFT' });
                  lastSwipeTime = now; prevPalmX = null;
                } else { prevPalmX = palmX; }
              } else { prevPalmX = palmX; }
            }

            //  Draw skeleton 
            drawConnectors(ctx, lm, HAND_CONNECTIONS,
              { color: sliderModeRef.current ? 'rgba(0,230,118,0.5)' : '#00e676', lineWidth: 2 });
            drawLandmarks(ctx, lm,
              { color: '#7c3aed', lineWidth: 1, radius: 3 });

            //  Static gesture classification 
            const raw   = classifyGesture(results.multiHandLandmarks, results.multiHandedness ?? []);
            const emoji = RAW_TO_EMOJI[raw] ?? '';

            if (emoji && raw !== 'Unknown') {
              ctx.save();
              ctx.font      = 'bold 38px serif';
              ctx.fillStyle = '#fff';
              ctx.shadowColor = 'rgba(0,0,0,0.5)';
              ctx.shadowBlur  = 6;
              ctx.fillText(emoji, 10, 44);
              ctx.restore();
            }

            //  Stable buffer fire 
            gestureBuffer.push(raw);
            if (gestureBuffer.length > BUFFER_SIZE) gestureBuffer.shift();
            const count = gestureBuffer.filter(g => g === raw).length;
            // Don't fire PINCH as a static gesture — it's handled via sliderMode
            if (count >= CONFIRM_COUNT && raw !== 'Unknown' && raw !== 'PINCH') {
              fireGesture(raw);
            }

          } else {
            // No hand detected → reset everything
            gestureBuffer  = [];
            prevPalmX      = null;
            isPinchedState = false;
          }

          ctx.restore();
        });

        const loop = async () => {
          if (cancelled) return;
          const v = videoRef.current;
          if (v && !v.paused && v.readyState >= 2) {
            try { await handsInstance.send({ image: v }); } catch (_) {}
          }
          animId = requestAnimationFrame(loop);
        };
        animId = requestAnimationFrame(loop);

      } catch (err) {
        console.error('GestureControl init error:', err);
      }
    };

    init();

    return () => {
      cancelled = true;
      cancelAnimationFrame(animId);
      stream?.getTracks().forEach(t => t.stop());
      handsInstance?.close?.();
    };
  }, []);
}