import { useCallback, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import apiClient from '../../api/client';
import type { GestureEvent } from '../../hooks/useGestureControl';
import GestureCamera from '../../components/GestureCamera/GestureCamera';
import './OperatorTransactionLimit.css';

type Step = 'SET_AMOUNT' | 'LOCK_CONFIRM' | 'APPROVE' | 'DONE';

const MIN_AMOUNT  =     100;
const MAX_AMOUNT  = 100_000;
const SNAP_STEP   =     500; // snap to nearest ₹500

export default function OperatorTransactionLimit() {
  const { currentUser } = useAuth();
  const navigate = useNavigate();

  const [step,      setStep]      = useState<Step>('SET_AMOUNT');
  const [amount,    setAmount]    = useState(5000);
  const [status,    setStatus]    = useState<'idle' | 'processing' | 'approved' | 'rejected'>('idle');
  const [message,   setMessage]   = useState('');

  // Slider visual state
  const [sliderPct,  setSliderPct]  = useState(0.05);   // 0..1 — CSS width %
  const [isPinched,  setIsPinched]  = useState(false);

  // Only update amount while pinched — ref so gesture callback is stable
  const isPinchedRef = useRef(false);
  const stepRef      = useRef(step);
  stepRef.current    = step;

  const logTransaction = async (approved: boolean, finalAmount: number) => {
    try {
      await apiClient.post('/api/logs', {
        userId:    currentUser?.userId,
        commandId: 'C_TRANSACTION',
        gestureId: approved ? 'G006' : 'G007',
        status:    approved ? 'success' : 'failed',
        metadata:  `Transaction limit ₹${finalAmount.toLocaleString('en-IN')}`,
      });
    } catch (_) { /* non-critical */ }
  };

  const handleGesture = useCallback((evt: GestureEvent) => {
    const cur = stepRef.current;

    //  HAND_POSITION: slider control (only during SET_AMOUNT) 
    if (evt.type === 'HAND_POSITION') {
      if (cur !== 'SET_AMOUNT') return;

      const pinched = evt.isPinched;
      isPinchedRef.current = pinched;
      setIsPinched(pinched);

      // Always update slider visual position (follows hand)
      setSliderPct(evt.normX);

      // Only commit the amount value when pinched (user is "grabbing")
      if (pinched) {
        const raw    = MIN_AMOUNT + evt.normX * (MAX_AMOUNT - MIN_AMOUNT);
        const snapped = Math.round(raw / SNAP_STEP) * SNAP_STEP;
        setAmount(Math.max(MIN_AMOUNT, Math.min(MAX_AMOUNT, snapped)));
      }
      return;
    }

    //  FIST → back 
    if (evt.type === 'FIST') {
      navigate('/operator/balance');
      return;
    }

    //  SET_AMOUNT step: Thumbs Up to lock 
    if (cur === 'SET_AMOUNT' && evt.type === 'THUMB_UP') {
      setStep('LOCK_CONFIRM');
      stepRef.current = 'LOCK_CONFIRM';
      setTimeout(() => {
        setStep('APPROVE');
        stepRef.current = 'APPROVE';
      }, 1800);
      return;
    }

    //  APPROVE step 
    if (cur === 'APPROVE') {
      if (evt.type === 'THUMB_UP') {
        setStatus('processing');
        setStep('DONE');
        stepRef.current = 'DONE';
        setAmount(prev => {
          logTransaction(true, prev);
          setMessage(`✅ Transaction limit of ₹${prev.toLocaleString('en-IN')} approved!`);
          return prev;
        });
        setTimeout(() => navigate('/operator/balance'), 2500);
      }
      if (evt.type === 'THUMB_DOWN') {
        setStatus('rejected');
        setStep('DONE');
        stepRef.current = 'DONE';
        setAmount(prev => { logTransaction(false, prev); return prev; });
        setMessage('❌ Transaction cancelled.');
        setTimeout(() => navigate('/operator/balance'), 2000);
      }
    }
  }, [navigate, currentUser]);

  const STEPS: Step[] = ['SET_AMOUNT', 'LOCK_CONFIRM', 'APPROVE', 'DONE'];
  const stepIdx = STEPS.indexOf(step);

  return (
    <div className="txn-layout">
      <header className="txn-header">
        <button className="txn-back-btn" onClick={() => navigate('/operator/balance')}>
          ← Back <span className="txn-gesture-hint">✊ Fist</span>
        </button>
        <div className="txn-brand">
          <span className="txn-title">Operator</span>
          <span className="txn-sub">Transaction Limit</span>
        </div>
        <div />
      </header>

      <main className="txn-main">
        <div className="txn-page">

          {/*  Left panel  */}
          <div className="txn-panel">

            {/* Step pills */}
            <div className="txn-steps">
              {STEPS.map((s, i) => (
                <div key={s} className={`txn-step ${step === s ? 'active' : ''} ${stepIdx > i ? 'done' : ''}`}>
                  <div className="step-dot">{i + 1}</div>
                  <span>
                    {s === 'SET_AMOUNT'   ? 'Set Amount' :
                     s === 'LOCK_CONFIRM' ? 'Lock'       :
                     s === 'APPROVE'      ? 'Approve'    : 'Done'}
                  </span>
                </div>
              ))}
            </div>

            {/* Amount card */}
            <div className="txn-amount-card">
              <div className="txn-amount-label">Transaction Limit</div>
              <div className={`txn-amount-value ${
                status === 'approved' ? 'green' :
                status === 'rejected' ? 'red'   : ''
              }`}>
                ₹ {amount.toLocaleString('en-IN')}
              </div>
              <div className="txn-amount-sub">Account: {currentUser?.username}</div>

              {/* Horizontal slider — visible during SET_AMOUNT */}
              {step === 'SET_AMOUNT' && (
                <div className="amount-slider-wrapper">
                  {/* State label */}
                  <div className={`slider-state-label ${isPinched ? 'dragging' : 'idle'}`}>
                    {isPinched ? '🤏 Dragging — value updating' : '🖐️ Pinch hand to grab slider'}
                  </div>

                  {/* Track */}
                  <div className="amount-slider-track">
                    <div
                      className={`amount-slider-fill ${isPinched ? 'active' : ''}`}
                      style={{ width: `${(sliderPct * 100).toFixed(1)}%` }}
                    />
                    <div
                      className={`amount-slider-thumb ${isPinched ? 'active' : ''}`}
                      style={{ left: `calc(${(sliderPct * 100).toFixed(1)}% - 12px)` }}
                    />
                  </div>

                  {/* Range labels */}
                  <div className="slider-range-labels">
                    <span>₹{MIN_AMOUNT.toLocaleString('en-IN')}</span>
                    <span>₹{MAX_AMOUNT.toLocaleString('en-IN')}</span>
                  </div>
                </div>
              )}
            </div>

            {/* Step instructions */}
            {step === 'SET_AMOUNT' && (
              <div className="txn-instructions">
                <div className="inst-row">🖐️ <span>Show open palm to see the slider</span></div>
                <div className="inst-row">🤏 <span>Pinch fingers to <strong>grab</strong> the slider</span></div>
                <div className="inst-row">👈 <span>Move hand <strong>left</strong> to decrease</span></div>
                <div className="inst-row">👉 <span>Move hand <strong>right</strong> to increase</span></div>
                <div className="inst-row">👍 <span>Thumbs Up to <strong>lock</strong> amount</span></div>
                <div className="inst-row">✊ <span>Fist to go back</span></div>
              </div>
            )}

            {step === 'LOCK_CONFIRM' && (
              <div className="txn-instructions locking">
                <div className="lock-icon">🔒</div>
                <p>Amount locked at <strong>₹{amount.toLocaleString('en-IN')}</strong></p>
                <p className="hint-small">Preparing approval…</p>
              </div>
            )}

            {step === 'APPROVE' && (
              <div className="txn-instructions approval">
                <p className="approve-prompt">Confirm transaction limit?</p>
                <div className="approve-actions">
                  <div className="approve-btn green-hint">👍 <span>Thumbs Up — Approve</span></div>
                  <div className="approve-btn red-hint">👎 <span>Thumbs Down — Cancel</span></div>
                </div>
              </div>
            )}

            {step === 'DONE' && (
              <div className={`txn-result ${status}`}>
                <div className="result-msg">{message}</div>
                <div className="result-hint">Returning to Balance page…</div>
              </div>
            )}
          </div>

          {/*  Right panel: camera  */}
          <div className="txn-camera-panel">
            <GestureCamera
              onGesture={handleGesture}
              sliderMode={step === 'SET_AMOUNT'}
            />
            {step === 'SET_AMOUNT' && (
              <div className={`slider-hint-bar ${isPinched ? 'active' : ''}`}>
                {isPinched
                  ? '🤏 Pinched · Move hand left/right · 👍 to lock'
                  : '🖐️ Show open palm then pinch to drag · 👍 to lock'}
              </div>
            )}
          </div>

        </div>
      </main>
    </div>
  );
}