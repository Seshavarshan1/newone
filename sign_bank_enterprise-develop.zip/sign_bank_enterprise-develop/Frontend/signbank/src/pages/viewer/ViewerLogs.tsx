import { useState, useEffect, useCallback, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import PortalLayout from '../../components/Layout/PortalLayout';
import GestureCamera from '../../components/GestureCamera/GestureCamera';
import { fetchLogsByUser, fetchLogs } from '../../api/logsApi';
import { useAuth } from '../../context/AuthContext';
import type { InteractionLog } from '../../types';
import type { GestureEvent } from '../../hooks/useGestureControl';
import './ViewerLogs.css';

const POLL_INTERVAL_MS = 15_000;

const GESTURE_SYMBOL_MAP: Record<string, string> = {
  G001: '☝️', G002: '✌️', G003: '🤌', G004: '🤘',
  G005: '🖐️', G006: '👍', G007: '👎', G008: '✊', G009: '🤟',
};
const NAME_SYMBOL_MAP: Record<string, string> = {
  ONE_FINGER: '☝️', TWO_FINGER: '✌️', THREE_FINGER: '🤌',
  CLOSED_MIDDLE_TWO_FINGER: '🤘', OPEN_PALM: '🖐️',
  THUMBS_UP: '👍', THUMBS_DOWN: '👎', FIST: '✊',
};
function getGestureEmoji(g: { gestureId: string; gestureName: string; gestureSymbol: string } | null): string {
  if (!g) return '—';
  if (g.gestureSymbol && /\p{Emoji}/u.test(g.gestureSymbol)) return g.gestureSymbol;
  return GESTURE_SYMBOL_MAP[g.gestureId] ?? NAME_SYMBOL_MAP[g.gestureName] ?? '🤚';
}

export default function ViewerLogs() {
  const { currentUser } = useAuth();
  const navigate = useNavigate();
  const [logs,    setLogs]    = useState<InteractionLog[]>([]);
  const [loading, setLoading] = useState(true);
  const [error,   setError]   = useState('');
  const [lastRefresh, setLastRefresh] = useState<Date | null>(null);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const loadLogs = useCallback(async () => {
    if (!currentUser) return;
    try {
      let data: InteractionLog[] = [];
      try {
        // Use the dedicated /user/{userId} endpoint — returns only this user's logs
        data = await fetchLogsByUser(currentUser.userId);
      } catch {
        // Fallback: get all and filter locally
        const all = await fetchLogs();
        data = all.filter(l =>
          l.user?.userId === currentUser.userId ||
          l.user?.username === currentUser.username
        );
      }
      data.sort((a, b) => new Date(b.executedAt).getTime() - new Date(a.executedAt).getTime());
      setLogs(data);
      setError('');
      setLastRefresh(new Date());
    } catch {
      setError('Failed to load logs.');
    } finally {
      setLoading(false);
    }
  }, [currentUser]);

  useEffect(() => {
    loadLogs();
    timerRef.current = setInterval(loadLogs, POLL_INTERVAL_MS);
    return () => { if (timerRef.current) clearInterval(timerRef.current); };
  }, [loadLogs]);

  const handleGesture = useCallback((evt: GestureEvent) => {
    if (evt.type === 'GESTURE_ID' && evt.id === 'G003') navigate('/viewer/dashboard');
  }, [navigate]);

  const success = logs.filter(l => l.status === 'success').length;
  const failed  = logs.filter(l => l.status === 'failed').length;

  return (
    <PortalLayout title="Viewer" subtitle="Logs" backPath="/viewer/dashboard" showLogout={false}>
      <div className="viewer-logs-layout">
        <div className="logs-content">
          <div className="logs-header-row">
            <h2>Interaction Logs</h2>
            <div className="logs-meta">
              {lastRefresh && <span className="last-refresh">Updated: {lastRefresh.toLocaleTimeString()}</span>}
              <button className="refresh-btn" onClick={loadLogs} disabled={loading}>
                {loading ? '⟳ Loading…' : '⟳ Refresh'}
              </button>
            </div>
          </div>

          <div className="log-summary-row">
            <div className="log-pill total">📋 {logs.length} Total</div>
            <div className="log-pill success">✅ {success} Success</div>
            <div className="log-pill failed">❌ {failed} Failed</div>
          </div>

          {error && <div className="logs-error">{error}</div>}

          <div className="table-card">
            <table className="logs-table">
              <thead>
                <tr><th>Log ID</th><th>Command</th><th>Gesture</th><th>Status</th><th>Time</th><th>Metadata</th></tr>
              </thead>
              <tbody>
                {loading && logs.length === 0 ? (
                  <tr><td colSpan={6} className="empty-row">Loading logs…</td></tr>
                ) : logs.length === 0 ? (
                  <tr><td colSpan={6} className="empty-row">No interaction logs found for your account</td></tr>
                ) : logs.map(l => (
                  <tr key={l.interactionId}>
                    <td className="log-id">{l.interactionId}</td>
                    <td>{l.command?.commandName ?? '—'}</td>
                    <td className="gesture-cell">
                      {l.gesture
                        ? <><span className="gesture-sym">{getGestureEmoji(l.gesture)}</span> {l.gesture.gestureName}</>
                        : '—'}
                    </td>
                    <td>
                      <span className={`status-badge ${l.status}`}>
                        {l.status === 'success' ? '✅' : '❌'} {l.status}
                      </span>
                    </td>
                    <td className="time-cell">{new Date(l.executedAt).toLocaleString()}</td>
                    <td className="meta-cell">{l.metadata || '—'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
        <GestureCamera onGesture={handleGesture} />
      </div>
    </PortalLayout>
  );
}