package com.signbank.backend.controller;

import com.signbank.backend.dto.AuthResponse;
import com.signbank.backend.dto.RegisterRequest;
import com.signbank.backend.entity.User;
import com.signbank.backend.repository.UserRepository;
import com.signbank.backend.security.JwtUtil;
import com.signbank.backend.service.AuthService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private final UserRepository userRepo;
    private final JwtUtil jwtUtil;
    private final AuthService authService;
    private final PasswordEncoder passwordEncoder;

    public AuthController(UserRepository userRepo, JwtUtil jwtUtil,
                          AuthService authService, PasswordEncoder passwordEncoder) {
        this.userRepo = userRepo;
        this.jwtUtil = jwtUtil;
        this.authService = authService;
        this.passwordEncoder = passwordEncoder;
    }

    @PostMapping("/login")
    public ResponseEntity<String> login(
            @RequestParam(name = "userId") String userId,
            @RequestParam(name = "password", required = false) String password) {

        User user = userRepo.findById(userId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "User not found"));

        String roleName = user.getRole().getRoleName().toLowerCase();

        //  Step 1: no password/gesture supplied 
        if (password == null || password.isBlank()) {
            if (roleName.equals("admin")) {
                throw new ResponseStatusException(HttpStatus.UNAUTHORIZED,
                        "Password required for admin");
            }
            // Operator/Viewer: check if password_hash is set
            if (user.getPasswordHash() == null || user.getPasswordHash().isBlank()) {
                return ResponseEntity.ok("FIRST_LOGIN");
            }
            return ResponseEntity.ok("PASSWORD_REQUIRED");
        }

        // Step 2: verify the supplied password/gesture sequence
        String stored = user.getPasswordHash();

        if (stored == null || stored.isBlank()) {
            // No password set — send to first login
            return ResponseEntity.ok("FIRST_LOGIN");
        }

        boolean authenticated;
        if (stored.startsWith("$2a$") || stored.startsWith("$2b$") || stored.startsWith("$2y$")) {
            // Proper BCrypt hash — works for BOTH admin password AND gesture sequence hash
            authenticated = passwordEncoder.matches(password, stored);
        } else {
            // Plain-text placeholder in DB (e.g. admin seed data)
            // Compare directly then auto-upgrade to BCrypt
            authenticated = password.equals(stored);
            if (authenticated) {
                user.setPasswordHash(passwordEncoder.encode(password));
                userRepo.save(user);
            }
        }

        if (!authenticated) {
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Invalid credentials");
        }

        String token = jwtUtil.generateToken(
                user.getUserId(),
                user.getRole().getRoleName().toUpperCase()
        );
        return ResponseEntity.ok(token);
    }

    // Set Password
    @PostMapping("/set-password")
    public ResponseEntity<String> setPassword(
            @RequestParam String userId,
            @RequestParam String newPassword) {

        if (newPassword == null || newPassword.isBlank()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                    "Password cannot be empty");
        }

        User user = userRepo.findById(userId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND,
                        "User not found"));

        // BCrypt hash the gesture sequence (or admin password) and store in password_hash
        user.setPasswordHash(passwordEncoder.encode(newPassword));
        userRepo.save(user);

        String token = jwtUtil.generateToken(
                user.getUserId(),
                user.getRole().getRoleName().toUpperCase()
        );
        return ResponseEntity.ok(token);
    }

    
    //   RESET PASSWORD — admin resets any user's password.
     
    @PostMapping("/reset-password")
    public ResponseEntity<String> resetPassword(
            @RequestParam String userId,
            @RequestParam String newPassword) {

        User user = userRepo.findById(userId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND,
                        "User not found"));

        user.setPasswordHash(passwordEncoder.encode(newPassword));
        userRepo.save(user);
        return ResponseEntity.ok("Password reset for " + userId);
    }

    @PostMapping("/register")
    public ResponseEntity<AuthResponse> register(
            @Valid @RequestBody RegisterRequest request) {
        return ResponseEntity.ok(authService.register(request));
    }
}