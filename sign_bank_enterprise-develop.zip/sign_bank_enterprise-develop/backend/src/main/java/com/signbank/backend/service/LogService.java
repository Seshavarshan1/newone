package com.signbank.backend.service;

import com.signbank.backend.dto.*;
import com.signbank.backend.entity.*;
import com.signbank.backend.repository.*;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class LogService {

    private final InteractionLogRepository repository;
    private final CommandRepository commandRepository;
    private final UserRepository userRepository;
    private final GestureRepository gestureRepository;

    public LogService(InteractionLogRepository repository,
                      CommandRepository commandRepository,
                      UserRepository userRepository,
                      GestureRepository gestureRepository) {
        this.repository = repository;
        this.commandRepository = commandRepository;
        this.userRepository = userRepository;
        this.gestureRepository = gestureRepository;
    }

    public InteractionLog saveLog(LogRequestDTO dto) {
        InteractionLog log = new InteractionLog();
        log.setInteractionId("L" + System.currentTimeMillis());

        // Use managed entities — not detached shells that cause FK errors
        if (dto.getCommandId() != null) {
            commandRepository.findById(dto.getCommandId()).ifPresent(log::setCommand);
        }
        if (dto.getUserId() != null) {
            userRepository.findById(dto.getUserId()).ifPresent(log::setUser);
        }
        if (dto.getGestureId() != null) {
            gestureRepository.findById(dto.getGestureId()).ifPresent(log::setGesture);
        }

        log.setExecutedAt(LocalDateTime.now());
        log.setStatus(dto.getStatus() != null ? dto.getStatus() : "success");
        log.setMetadata(dto.getMetadata());
        return repository.save(log);
    }

    public List<InteractionLog> getAllLogs() { return repository.findAll(); }
    public List<LogResponseDTO> getDetailedLogs() { return repository.getDetailedLogs(); }
    public List<InteractionLog> getLogsByUser(String userId) { return repository.getLogsByUser(userId); }

    public AnalyticsResponseDTO getAnalytics() {
        long total = repository.getTotalLogs();
        long activeUsers = repository.getActiveUsers();
        long successLogs = repository.getSuccessLogs();
        double successRate = (total == 0) ? 0 : ((double) successLogs / total) * 100;
        return new AnalyticsResponseDTO(total, activeUsers, successRate);
    }

    public List<InteractionLog> filterLogs(String userId, String status) {
        return repository.filterLogs(userId, status);
    }
}