package com.signbank.backend.controller;

import com.signbank.backend.dto.AuthResponse;
import com.signbank.backend.dto.RegisterRequest;
import com.signbank.backend.entity.User;
import com.signbank.backend.repository.UserRepository;
import com.signbank.backend.security.JwtUtil;
import com.signbank.backend.service.AuthService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.http.HttpStatus;

/**
 * Authentication flow — three endpoints used by the frontend:
 *
 * 1. POST /api/auth/login?userId=1111
 *    → Returns "FIRST_LOGIN"        if password_hash IS NULL
 *    → Returns "PASSWORD_REQUIRED"  if password_hash IS SET
 *    → Returns JWT                  if userId=U000 (admin check handled by password call)
 *
 * 2. POST /api/auth/login?userId=1111&password=G001-G002-G003
 *    → BCrypt-verifies password against password_hash
 *    → Returns JWT on success, 401 on failure
 *
 * 3. POST /api/auth/set-password?userId=1111&newPassword=G001-G002-G003
 *    → BCrypt-hashes newPassword into password_hash
 *    → Returns JWT so user is auto-logged-in
 */
@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private final UserRepository  userRepo;
    private final JwtUtil         jwtUtil;
    private final AuthService     authService;
    private final PasswordEncoder passwordEncoder;

    public AuthController(
            UserRepository  userRepo,
            JwtUtil         jwtUtil,
            AuthService     authService,
            PasswordEncoder passwordEncoder
    ) {
        this.userRepo        = userRepo;
        this.jwtUtil         = jwtUtil;
        this.authService     = authService;
        this.passwordEncoder = passwordEncoder;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // POST /api/auth/login
    //
    // Called TWICE by the frontend:
    //   Call 1 — no password param  → check if password is set, return status string
    //   Call 2 — with password param → verify & return JWT
    // ─────────────────────────────────────────────────────────────────────────
    @PostMapping("/login")
    public ResponseEntity<String> login(
            @RequestParam(name = "userId",   required = true)  String userId,
            @RequestParam(name = "password", required = false) String password
    ) {
        // Look up user — 404 if not found
        User user = userRepo.findById(userId)
                .orElseThrow(() ->
                        new ResponseStatusException(HttpStatus.NOT_FOUND, "User not found"));

        final String roleName = user.getRole() != null
                ? user.getRole().getRoleName().toUpperCase()
                : "OPERATOR";

        // ── Call 2: password supplied → verify and return JWT ─────────────
        if (password != null && !password.isBlank()) {

            final String storedHash = user.getPasswordHash();

            if (storedHash == null || storedHash.isBlank()) {
                // No password set yet — tell frontend to go to set-password
                return ResponseEntity.ok("FIRST_LOGIN");
            }

            // BCrypt verification
            boolean valid;
            if (storedHash.startsWith("$2a$") || storedHash.startsWith("$2b$")) {
                // Proper BCrypt hash
                valid = passwordEncoder.matches(password, storedHash);
            } else {
                // Plain-text stored (dev/seed data) — compare directly
                // On first successful plain-text match, upgrade to BCrypt
                valid = storedHash.equals(password);
                if (valid) {
                    user.setPasswordHash(passwordEncoder.encode(password));
                    userRepo.save(user);
                }
            }

            if (!valid) {
                throw new ResponseStatusException(HttpStatus.UNAUTHORIZED,
                        "Wrong password");
            }

            String token = jwtUtil.generateToken(user.getUserId(), roleName);
            return ResponseEntity.ok(token);
        }

        // ── Call 1: no password → return status string ────────────────────
        if (user.getPasswordHash() == null || user.getPasswordHash().isBlank()) {
            return ResponseEntity.ok("FIRST_LOGIN");
        } else {
            return ResponseEntity.ok("PASSWORD_REQUIRED");
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // POST /api/auth/set-password?userId=1111&newPassword=G001-G002-G003
    //
    // First-login flow: BCrypt-hash the gesture sequence and store it.
    // Returns a JWT so the user is auto-logged-in after setting password.
    // ─────────────────────────────────────────────────────────────────────────
    @PostMapping("/set-password")
    public ResponseEntity<String> setPassword(
            @RequestParam(name = "userId")      String userId,
            @RequestParam(name = "newPassword") String newPassword
    ) {
        User user = userRepo.findById(userId)
                .orElseThrow(() ->
                        new ResponseStatusException(HttpStatus.NOT_FOUND, "User not found"));

        if (newPassword == null || newPassword.isBlank()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                    "newPassword must not be blank");
        }

        // BCrypt-hash and save
        user.setPasswordHash(passwordEncoder.encode(newPassword));
        userRepo.save(user);

        final String roleName = user.getRole() != null
                ? user.getRole().getRoleName().toUpperCase()
                : "OPERATOR";

        String token = jwtUtil.generateToken(user.getUserId(), roleName);
        return ResponseEntity.ok(token);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // POST /api/auth/register  (existing — unchanged)
    // ─────────────────────────────────────────────────────────────────────────
    @PostMapping("/register")
    public ResponseEntity<AuthResponse> register(
            @Valid @RequestBody RegisterRequest request
    ) {
        return ResponseEntity.ok(authService.register(request));
    }
}