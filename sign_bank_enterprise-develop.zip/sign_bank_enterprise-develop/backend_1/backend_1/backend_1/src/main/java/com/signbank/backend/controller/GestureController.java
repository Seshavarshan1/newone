package com.signbank.backend.controller;

import com.signbank.backend.dto.LandmarkRequest;
import com.signbank.backend.dto.LandmarkResponse;
import com.signbank.backend.dto.SetLimitRequest;
import com.signbank.backend.dto.request.GestureEventRequest;
import com.signbank.backend.dto.response.GestureEventResponse;
import com.signbank.backend.service.GestureService;
import com.signbank.backend.service.OpenCvFingerTrackingService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@CrossOrigin(origins = "*")  
public class GestureController {

    private final GestureService gestureService;
    private final OpenCvFingerTrackingService fingerTrackingService;

    public GestureController(GestureService gestureService,
                             OpenCvFingerTrackingService fingerTrackingService) {
        this.gestureService        = gestureService;
        this.fingerTrackingService = fingerTrackingService;
    }

    @PostMapping("/api/gesture-events")
    public GestureEventResponse handleGesture(
            @RequestBody GestureEventRequest request) {
        return gestureService.handleGesture(request);
    }


    @PostMapping("/api/operator/analyse-finger")
    public ResponseEntity<LandmarkResponse> analyseFinger(
            @RequestBody LandmarkRequest request,
            @RequestParam(defaultValue = "default") String userId) {

        LandmarkResponse response = fingerTrackingService.analyseFinger(request, userId);
        return ResponseEntity.ok(response);
    }


    @PostMapping("/api/operator/set-limit")
    public ResponseEntity<Map<String, Object>> setTransactionLimit(
            @Valid @RequestBody SetLimitRequest request) {

        fingerTrackingService.confirmLimit(request.getUserId(), request.getLimit());

        Map<String, Object> body = new HashMap<>();
        body.put("userId",  request.getUserId());
        body.put("limit",   request.getLimit());
        body.put("status",  "success");
        body.put("message", "Transaction limit set to ₹" + String.format("%.0f", request.getLimit()));
        return ResponseEntity.ok(body);
    }

    @GetMapping("/api/operator/set-limit")
    public ResponseEntity<Map<String, Object>> getTransactionLimit(
            @RequestParam String userId) {
        double limit = fingerTrackingService.getLimit(userId);
        Map<String, Object> body = new HashMap<>();
        body.put("userId", userId);
        body.put("limit",  limit);
        body.put("status", "success");
        return ResponseEntity.ok(body);
    }
}