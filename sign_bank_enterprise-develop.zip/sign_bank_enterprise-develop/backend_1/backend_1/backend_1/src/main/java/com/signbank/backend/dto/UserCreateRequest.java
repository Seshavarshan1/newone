package com.signbank.backend.dto;

public class UserCreateRequest {


    private String userId;      // NEW (ER based)
    private String username;
    private String email;
    private String roleId;

    private String passwordHash; // for ADMIN
    private String gestureHash;  // for OPERATOR / VIEWER

    public String getUserId(){
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getRoleId() {
        return roleId;
    }

    public void setRoleId(String roleId) {
        this.roleId = roleId;
    }

    public String getPasswordHash() {
        return passwordHash;
    }

    public void setPasswordHash(String passwordHash) {
        this.passwordHash = passwordHash;
    }

    public String getGestureHash() {
        return gestureHash;
    }

    public void setGestureHash(String gestureHash) {
        this.gestureHash = gestureHash;
    }
}