package com.signbank.backend.security;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

import java.util.List;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

    private final JwtAuthFilter jwtAuthFilter;

    public SecurityConfig(JwtAuthFilter jwtAuthFilter) {
        this.jwtAuthFilter = jwtAuthFilter;
    }

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
            .cors(cors -> cors.configurationSource(corsConfigurationSource()))
            .csrf(csrf -> csrf.disable())
            .sessionManagement(sm -> sm.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
            .authorizeHttpRequests(auth -> auth
                // ── Auth (public) ─────────────────────────────────────────
                .requestMatchers("/api/auth/**").permitAll()

                // ── Gesture events (public) ───────────────────────────────
                .requestMatchers("/api/gesture-events").permitAll()

                // ── Admin read-only endpoints needed by GestureLogin ──────
                // GestureLogin fetches /api/admin/users to get roleId,
                // and /api/admin/gestures for the emoji list.
                // These are called before the user has a token.
                .requestMatchers(HttpMethod.GET, "/api/admin/users").permitAll()
                .requestMatchers(HttpMethod.GET, "/api/admin/gestures").permitAll()
                .requestMatchers(HttpMethod.GET, "/api/admin/commands").permitAll()
                .requestMatchers(HttpMethod.GET, "/api/admin/mappings").permitAll()
                .requestMatchers(HttpMethod.GET, "/api/admin/pages").permitAll()
                .requestMatchers(HttpMethod.GET, "/api/admin/roles").permitAll()

                // ── Operator gesture/limit endpoints ─────────────────────
                .requestMatchers(HttpMethod.POST, "/api/operator/analyse-finger").permitAll()
                .requestMatchers(HttpMethod.POST, "/api/operator/analyse-rotation").permitAll()
                .requestMatchers(HttpMethod.POST, "/api/operator/set-limit").permitAll()
                .requestMatchers(HttpMethod.GET,  "/api/operator/set-limit").permitAll()

                // ── Logs (viewer reads logs without extra auth issues) ─────
                .requestMatchers(HttpMethod.GET,  "/api/logs/**").permitAll()
                .requestMatchers(HttpMethod.POST, "/api/logs").permitAll()

                // ── Everything else requires a valid JWT ──────────────────
                .anyRequest().authenticated()
            )
            .addFilterBefore(jwtAuthFilter, UsernamePasswordAuthenticationFilter.class);

        return http.build();
    }

    @Bean
    public CorsConfigurationSource corsConfigurationSource() {
        CorsConfiguration config = new CorsConfiguration();
        config.setAllowedOriginPatterns(List.of(
            "http://localhost:*",
            "http://127.0.0.1:*"
        ));
        // PATCH added for mapping status toggle
        config.setAllowedMethods(List.of("GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"));
        config.setAllowedHeaders(List.of("*"));
        config.setAllowCredentials(true);

        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/**", config);
        return source;
    }

    @Bean
    public AuthenticationManager authenticationManager(
            AuthenticationConfiguration config) throws Exception {
        return config.getAuthenticationManager();
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }
}