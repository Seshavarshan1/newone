***

# Vision Module Interface Specification

### SignBank Enterprise – Gesture‑Driven Smart Interaction Platform

## Overview

The **Vision Module** is a client-side subsystem responsible for detecting, classifying, and emitting stable gesture events to the backend. This document outlines the structure, rules, and expectations for communication between the Vision Module (MediaPipe + React) and the Backend Gesture Processing Service.

Its goal is to ensure consistent, reliable, and scalable integration across the SignBank Enterprise ecosystem.

***

## 1. Purpose

This specification defines:

*   The structure of gesture event data produced by the Vision Module
*   Required backend API endpoint(s)
*   Validation rules and constraints
*   Processing behavior and assumptions

This enables seamless mapping from physical gestures → system‑level commands.

***

## 2. System Context

High‑level workflow:

1.  Webcam captures user hand movements
2.  MediaPipe extracts hand landmarks
3.  Vision Module classifies gestures
4.  Gesture events are sent to the backend via REST API
5.  Backend resolves gestures into commands and executes logic

All gesture intelligence (detection/classification) occurs on the client.

***

## 3. Vision Module Responsibilities

### Performs:

*   Real‑time gesture detection
*   Classification into predefined categories
*   Stability filtering (buffering, debouncing, confidence)
*   Emission of structured gesture events

### Does *not* perform:

*   Command mapping
*   Authentication
*   Persistence or logging
*   Business logic

***

## 4. Gesture Event Data Specification

### 4.1 Standard Gesture Event Object

    {
      "gestureType": "DIGIT | FUNCTIONAL",
      "gestureCode": "string",
      "confidence": number,
      "gestureId": "string (optional)",
      "context": {
        "screen": "LOGIN | DASHBOARD | ADMIN"
      }
    }

### 4.2 Field Details

**gestureType**

*   DIGIT → numeric input gestures
*   FUNCTIONAL → action-based gestures

**gestureCode**

*   DIGIT: `"0"` to `"9"`
*   FUNCTIONAL:
    *   THUMB\_UP
    *   THUMB\_DOWN
    *   FIST
    *   ROCK
    *   OK
    *   CALL ME SIGN

**confidence (0.0–1.0)**  
Computed as:

    confidence = stable frames / buffer size

**gestureId (optional)**  
Standardized mapping (G001–G016) for digits and functional gestures.

**context.screen**  
Indicates current frontend state:

*   LOGIN
*   DASHBOARD
*   ADMIN

Used by backend for context‑aware mapping.

### 4.3 Example Payloads

Functional Gesture:

    {
      "gestureType": "FUNCTIONAL",
      "gestureCode": "FIST",
      "confidence": 0.91,
      "context": { "screen": "DASHBOARD" }
    }

Numeric Gesture:

    {
      "gestureType": "DIGIT",
      "gestureCode": "3",
      "confidence": 0.94,
      "gestureId": "G003",
      "context": { "screen": "LOGIN" }
    }

***

## 5. Gesture Processing Characteristics

Vision Module ensures stability through:

*   Temporal validation (multiple consistent frames)
*   Debouncing via buffer
*   Minimum threshold (\~5 stable frames)
*   Cooldown (\~1200 ms)

Results in reliable, low‑noise event emission.

***

## 6. Backend API Requirements

### 6.1 Endpoint

    POST /api/gesture-events

### 6.2 Purpose

Accept gesture events → validate → map → execute business logic.

### 6.3 Request Payload Example

    {
      "gestureType": "FUNCTIONAL",
      "gestureCode": "CALL ME SIGN",
      "confidence": 0.89,
      "gestureId": "G016",
      "context": { "screen": "DASHBOARD" }
    }

### 6.4 Backend Responsibilities

*   Validate payload
*   Identify session/user
*   Map gesture → command
*   Execute mapped logic
*   Log interaction

### 6.5 Response Format

    {
      "status": "SUCCESS | FAILED",
      "resolvedCommand": "LOGIN | APPROVE | CANCEL | CONFIRM | VIEW_LOGS",
      "message": "optional"
    }

***

## 7. Validation Rules

Backend must enforce:

### gestureType

Must be: DIGIT or FUNCTIONAL

### gestureCode

Must match predefined values

### confidence

    0.0 <= confidence <= 1.0

### Reject conditions

*   Unknown gesture codes
*   Unsupported gesture types
*   Invalid confidence values
*   Malformed requests

***

## 8. Data Transmission Constraints

Vision Module **only sends**:

*   Processed gesture events

It **never sends**:

*   Raw video frames
*   Hand landmarks
*   Frame‑by‑frame data

Keeps bandwidth low and preserves privacy.

***

## 9. Performance Expectations

*   Average rate: **2–5 events/sec**
*   Peak rate: **up to 10 events/sec**
*   Backend should be stateless and lightweight

***

## 10. Assumptions

*   Gesture detection is client‑side
*   Only validated gestures are transmitted
*   Backend handles business logic, state, and persistence
*   Network latency may affect responsiveness

***

